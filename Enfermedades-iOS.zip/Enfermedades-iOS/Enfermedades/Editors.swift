import SwiftUI
import PhotosUI
import UniformTypeIdentifiers
import ImageIO
import UIKit

struct IllnessForm: View {
    @Environment(Journal.self) private var journal
    @Environment(\.dismiss) private var dismiss
    @State var illness: Illness
    let creating: Bool
    let onSave: (UUID) -> Void
    @State private var staged: [String: Data] = [:]
    @State private var importing = false
    @State private var error: String?

    init(illness: Illness, creating: Bool, onSave: @escaping (UUID) -> Void) {
        _illness = State(initialValue: illness)
        self.creating = creating
        self.onSave = onSave
    }

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    TextField("Nombre de la enfermedad", text: $illness.name)
                        .textInputAutocapitalization(.sentences)
                    TextField("Descripción breve", text: $illness.summary, axis: .vertical)
                        .lineLimit(2...5)
                }
                Section("Cabecera") {
                    Picker("Animación", selection: Binding<HeaderStyle>(
                        get: { illness.animation },
                        set: { illness.animation = $0 }
                    )) {
                        ForEach(HeaderStyle.allCases.filter { $0 != .gif || illness.gif != nil }) { style in
                            Label(style.label, systemImage: style.icon).tag(style)
                        }
                    }
                    Button { importing = true } label: {
                        Label(illness.gif == nil ? "Importar GIF desde Archivos" : "Cambiar GIF",
                              systemImage: "square.and.arrow.up")
                    }
                    if illness.gif != nil {
                        Button("Quitar GIF", role: .destructive) {
                            if let gif = illness.gif { staged.removeValue(forKey: gif) }
                            illness.gif = nil
                            if illness.animation == .gif { illness.animation = .aurora }
                        }
                    }
                    HeaderArtwork(style: illness.animation,
                                  gifData: illness.gif.flatMap { staged[$0] },
                                  gifURL: illness.gif.map { journal.media($0) },
                                  reloadID: illness.animation.rawValue + (illness.gif ?? ""))
                        .frame(height: 142)
                        .background(Palette.surface)
                        .clipShape(.rect(cornerRadius: 17))
                        .listRowSeparator(.hidden)
                }
            }
            .navigationTitle(creating ? "Nueva enfermedad" : "Editar enfermedad")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancelar") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Guardar", systemImage: "checkmark", action: save)
                        .disabled(illness.name.trimmed.isEmpty)
                }
            }
            .fileImporter(isPresented: $importing, allowedContentTypes: [.gif], onCompletion: importGIF)
            .saveError($error)
        }
    }

    private func importGIF(_ result: Result<URL, Error>) {
        do {
            let url = try result.get()
            let accessed = url.startAccessingSecurityScopedResource()
            defer { if accessed { url.stopAccessingSecurityScopedResource() } }
            let size = try url.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0
            guard size <= 20 * 1024 * 1024 else {
                error = "Elige un GIF de hasta 20 MB."
                return
            }
            let data = try Data(contentsOf: url)
            guard data.count <= 20 * 1024 * 1024, GIFFrames.isGIF(data) else {
                error = "El archivo debe ser un GIF válido de hasta 20 MB."
                return
            }
            if let previous = illness.gif { staged.removeValue(forKey: previous) }
            let name = UUID().uuidString + ".gif"
            staged[name] = data
            illness.gif = name
            illness.animation = .gif
        } catch {
            self.error = error.localizedDescription
        }
    }

    private func save() {
        illness.name = illness.name.trimmed
        illness.summary = illness.summary.trimmed
        do {
            if !creating, let current = journal.illness(illness.id) { illness.entries = current.entries }
            try journal.save(illness, media: staged)
            dismiss()
            onSave(illness.id)
        } catch {
            self.error = error.localizedDescription
        }
    }
}

struct EntryForm: View {
    @Environment(Journal.self) private var journal
    @Environment(\.dismiss) private var dismiss
    let illnessID: UUID
    @State var entry: Entry
    @State private var picked: [PhotosPickerItem] = []
    @State private var staged: [String: Data] = [:]
    @State private var loadingPhotos = false
    @State private var healthKind: HealthKind?
    @State private var displayedPhoto: PhotoSelection?
    @State private var error: String?
    @State private var confirmingDelete = false

    init(illnessID: UUID, entry: Entry) {
        self.illnessID = illnessID
        _entry = State(initialValue: entry)
    }

    private var isNew: Bool {
        journal.illness(illnessID)?.entries.contains { $0.id == entry.id } != true
    }
    private let photoLimit = 12

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    TextField("Título", text: $entry.title)
                        .font(.headline)
                        .textInputAutocapitalization(.sentences)
                    TextField("Contenido", text: $entry.notes, axis: .vertical)
                        .lineLimit(4...12)
                    if !isNew {
                        Text(entry.created, format: .dateTime.day().month(.abbreviated).year().hour().minute())
                            .font(.caption).foregroundStyle(.secondary)
                    }
                }
                Section("Estado") {
                    VStack(alignment: .leading, spacing: 5) {
                        HStack {
                            Circle().fill(Palette.severity(entry.severity)).frame(width: 9, height: 9)
                            Text(entry.status).font(.headline)
                            Spacer()
                            Text("\(entry.severity) / 100").font(.caption.monospacedDigit()).foregroundStyle(.secondary)
                        }
                        .accessibilityHidden(true)
                        SeveritySlider(value: $entry.severity)
                    }
                    .padding(.vertical, 5)
                }
                Section("Adjuntos") {
                    if !entry.photos.isEmpty {
                        PhotoStrip(names: entry.photos, url: { journal.media($0) }, drafts: staged,
                                   remove: removePhoto, open: { displayedPhoto = PhotoSelection(id: $0) })
                    }
                    if loadingPhotos { ProgressView("Importando fotos…") }
                    if entry.photos.count < photoLimit {
                        PhotosPicker(selection: $picked, maxSelectionCount: photoLimit - entry.photos.count, matching: .images) {
                            Label("Añadir fotos", systemImage: "photo.on.rectangle.angled")
                        }
                        .disabled(loadingPhotos)
                    }
                    ForEach(entry.health) { item in
                        HStack {
                            HealthAttachmentLabel(item: item)
                            Spacer()
                            Button(role: .destructive) {
                                entry.health.removeAll { $0.id == item.id }
                            } label: {
                                Image(systemName: "minus.circle")
                            }
                            .buttonStyle(.borderless)
                            .accessibilityLabel("Quitar \(item.name)")
                        }
                    }
                    ForEach(HealthKind.allCases) { kind in
                        Button { healthKind = kind } label: { Label(kind.title, systemImage: kind.icon) }
                    }
                }
                if !isNew {
                    Section {
                        Button("Eliminar registro", role: .destructive) { confirmingDelete = true }
                    }
                }
            }
            .navigationTitle(isNew ? "Nuevo registro" : "Editar registro")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancelar") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Guardar", systemImage: "checkmark", action: save)
                        .disabled(entry.title.trimmed.isEmpty || loadingPhotos || !picked.isEmpty)
                }
            }
            .sheet(item: $healthKind) { kind in HealthPicker(kind: kind, selected: $entry.health) }
            .sheet(item: $displayedPhoto) { photo in
                PhotoPreview(url: journal.media(photo.id), bytes: staged[photo.id])
            }
            .task(id: picked) { await importPhotos(picked) }
            .confirmationDialog("¿Eliminar este registro?", isPresented: $confirmingDelete, titleVisibility: .visible) {
                Button("Eliminar registro", role: .destructive, action: delete)
            } message: {
                Text("También se quitarán sus adjuntos del historial de Enfermedades.")
            }
            .saveError($error)
        }
    }

    private func removePhoto(_ name: String) {
        staged.removeValue(forKey: name)
        entry.photos.removeAll { $0 == name }
    }

    private func importPhotos(_ selection: [PhotosPickerItem]) async {
        guard !selection.isEmpty else { return }
        loadingPhotos = true
        defer { loadingPhotos = false }
        var failed = false
        for item in selection.prefix(photoLimit - entry.photos.count) {
            guard !Task.isCancelled else { return }
            do {
                guard let source = try await item.loadTransferable(type: Data.self),
                      let jpeg = await Task.detached(priority: .userInitiated, operation: {
                          PhotoDecoder.thumbnail(bytes: source, url: nil, size: 1700)?.jpegData(compressionQuality: 0.85)
                      }).value else {
                    failed = true
                    continue
                }
                guard !Task.isCancelled else { return }
                let name = UUID().uuidString + ".jpg"
                staged[name] = jpeg
                entry.photos.append(name)
            } catch {
                failed = true
            }
        }
        if failed { error = "Algunas fotos no se pudieron cargar. Inténtalo de nuevo con esas fotos." }
        picked = []
    }

    private func save() {
        guard var illness = journal.illness(illnessID) else { return }
        let existing = illness.entries.first { $0.id == entry.id }
        entry.created = existing?.created ?? .now
        entry.title = entry.title.trimmed
        entry.notes = entry.notes.trimmed
        illness.put(entry)
        do {
            try journal.save(illness, media: staged)
            dismiss()
        } catch {
            self.error = error.localizedDescription
        }
    }

    private func delete() {
        guard var illness = journal.illness(illnessID) else { return }
        illness.entries.removeAll { $0.id == entry.id }
        do {
            try journal.save(illness)
            dismiss()
        } catch {
            self.error = error.localizedDescription
        }
    }
}

enum PhotoDecoder {
    static func thumbnail(bytes: Data?, url: URL?, size: Int) -> UIImage? {
        let source = bytes.flatMap { CGImageSourceCreateWithData($0 as CFData, nil) }
            ?? url.flatMap { CGImageSourceCreateWithURL($0 as CFURL, nil) }
        let options = [kCGImageSourceCreateThumbnailFromImageAlways: true,
                       kCGImageSourceCreateThumbnailWithTransform: true,
                       kCGImageSourceThumbnailMaxPixelSize: size] as [CFString: Any]
        guard let source, let image = CGImageSourceCreateThumbnailAtIndex(source, 0, options as CFDictionary) else { return nil }
        return UIImage(cgImage: image)
    }
}

private struct PhotoSelection: Identifiable { let id: String }

private struct PhotoPreview: View {
    let url: URL
    let bytes: Data?
    @Environment(\.dismiss) private var dismiss
    @State private var image: UIImage?
    @State private var finished = false

    var body: some View {
        NavigationStack {
            Group {
                if let image {
                    Image(uiImage: image).resizable().scaledToFit().accessibilityLabel("Foto adjunta")
                } else if finished {
                    ContentUnavailableView("No se pudo cargar la foto", systemImage: "photo")
                } else {
                    ProgressView()
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(.black)
            .navigationTitle("Foto adjunta")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) { Button("Listo") { dismiss() } }
            }
            .task {
                image = await Task.detached(priority: .userInitiated) {
                    PhotoDecoder.thumbnail(bytes: bytes, url: url, size: 1700)
                }.value
                finished = true
            }
        }
    }
}

private extension View {
    func saveError(_ message: Binding<String?>) -> some View {
        alert("Ocurrió un problema", isPresented: Binding(
            get: { message.wrappedValue != nil },
            set: { if !$0 { message.wrappedValue = nil } }
        )) {
            Button("Aceptar", role: .cancel) { message.wrappedValue = nil }
        } message: {
            Text(message.wrappedValue ?? "")
        }
    }
}
