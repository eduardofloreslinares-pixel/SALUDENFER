import SwiftUI
import UIKit

@main
struct EnfermedadesApp: App {
    @State private var journal = Journal()

    var body: some Scene {
        WindowGroup {
            HomeView()
                .environment(journal)
                .tint(Color(uiColor: .label))
                .environment(\.locale, Locale(identifier: "es_PE"))
        }
    }
}
