import SwiftUI

@main
struct EnfermedadesApp: App {
    @State private var journal = Journal()

    var body: some Scene {
        WindowGroup {
            HomeView()
                .environment(journal)
                .tint(Palette.accent)
                .environment(\.locale, Locale(identifier: "es_PE"))
        }
    }
}
