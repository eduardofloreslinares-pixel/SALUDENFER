import SwiftUI
import UIKit
import ImageIO
import UniformTypeIdentifiers

enum Palette {
    static let colors: [(Double, Double, Double)] = [
        (0.15, 0.76, 0.38), (0.53, 0.77, 0.22), (0.91, 0.72, 0.17),
        (0.95, 0.43, 0.15), (0.89, 0.17, 0.25)
    ]
    static let gradient = colors.map { Color(red: $0.0, green: $0.1, blue: $0.2) }

    static func severity(_ value: Int) -> Color {
        let index = min(max(Double(value) / 25, 0), 4)
        let low = colors[Int(index)]
        let high = colors[min(Int(index) + 1, 4)]
        let fraction = index - floor(index)
        return Color(red: low.0 + (high.0 - low.0) * fraction,
                     green: low.1 + (high.1 - low.1) * fraction,
                     blue: low.2 + (high.2 - low.2) * fraction)
    }
}

struct EntryStatus: View {
    let entry: Entry
    let previous: Entry?

    var body: some View {
        ViewThatFits(in: .horizontal) {
            HStack(spacing: 10) {
                severityLabel
                evolutionLabel
            }
            VStack(alignment: .leading, spacing: 5) {
                severityLabel
                evolutionLabel
            }
        }
        .font(.caption.weight(.semibold))
        .accessibilityElement(children: .combine)
    }

    private var severityLabel: some View {
        Label {
            Text(entry.status)
        } icon: {
            Image(systemName: entry.severity == 0 ? "checkmark.circle.fill" : "waveform.path.ecg")
                .foregroundStyle(Palette.severity(entry.severity))
                .accessibilityHidden(true)
        }
    }

    @ViewBuilder
    private var evolutionLabel: some View {
        if let evolution = entry.evolution(since: previous) {
            Label(evolution.rawValue, systemImage: evolution.icon)
                .foregroundStyle(.secondary)
        }
    }
}

struct BubbleSurface: ViewModifier {
    var tint: Color? = nil
    var interactive = false
    @Environment(\.colorScheme) private var scheme

    func body(content: Content) -> some View {
        let shape = RoundedRectangle(cornerRadius: 31, style: .circular)
        return content
            .background {
                if let tint {
                    shape.fill(LinearGradient(colors: [tint.opacity(scheme == .dark ? 0.38 : 0.27),
                                                        tint.opacity(0.09)], startPoint: .topLeading, endPoint: .bottomTrailing))
                }
            }
            .glassEffect(.regular.tint(tint?.opacity(0.20)).interactive(interactive), in: shape)
    }
}

struct HistoryPerspective {
    private let depth: CGFloat

    init(top: CGFloat, viewport: CGFloat) {
        let position = viewport > 0 ? top / viewport : 0
        let fraction = min(max((position - 0.38) / 0.57, 0), 1)
        depth = fraction * fraction * (3 - 2 * fraction)
    }

    var width: CGFloat { 1 - 0.24 * depth }
    var height: CGFloat { 1 - 0.32 * depth }
    var lift: CGFloat { -12 * depth }
    var opacity: Double { 1 - 0.73 * Double(depth) }

    func project(_ point: CGPoint, in rect: CGRect) -> CGPoint {
        CGPoint(x: rect.midX + (point.x - rect.midX) * width,
                y: rect.minY + (point.y - rect.minY) * height + lift)
    }
}

struct HistoryBubbleSurface: ViewModifier {
    let tint: Color
    let outline: HistoryOutline
    @Environment(\.colorScheme) private var scheme

    func body(content: Content) -> some View {
        content.background {
            let dark = scheme == .dark
            // Keep the sheen, fill and lettering in the same layer during scroll transforms.
            outline
                .fill(dark ? Color(white: 0.10) : Color(white: 0.98))
                .overlay {
                    outline.fill(LinearGradient(
                        colors: [tint.opacity(dark ? 0.35 : 0.22), tint.opacity(dark ? 0.18 : 0.08)],
                        startPoint: .topLeading, endPoint: .bottomTrailing
                    ))
                }
                .overlay {
                    outline.stroke(LinearGradient(
                        colors: [.white.opacity(dark ? 0.23 : 0.90), tint.opacity(0.17)],
                        startPoint: .topLeading, endPoint: .bottomTrailing
                    ), lineWidth: 0.8)
                }
        }
    }
}

struct HistoryWave {
    let severity: Int
    let time: TimeInterval
    let index: Int

    private var intensity: Double { min(max(Double(severity) / 100, 0), 1) }

    var outline: HistoryOutline {
        HistoryOutline(amplitude: 3.7 + 3.0 * intensity,
                       phase: time * (1.55 + 0.65 * intensity) + Double(index % 7) * 1.7)
    }

    func pulse(_ strand: Int) -> (distance: CGFloat, opacity: Double) {
        let period = 4.4 - 0.7 * intensity
        let cycle = time / period + Double(index) * 0.23 + Double(strand) / 2
        let age = cycle - floor(cycle)
        let emergence = min(age * 12, 1)
        return (2 + age * (43 + 9 * intensity),
                emergence * pow(1 - age, 1.30) * (0.69 + 0.19 * intensity))
    }
}

struct HistoryOutline: Shape {
    var amplitude: CGFloat = 0
    var phase: Double = 0

    func path(in rect: CGRect) -> Path {
        guard amplitude > 0 else {
            return RoundedRectangle(cornerRadius: 31, style: .circular).path(in: rect)
        }
        return Self.closedPath(points(in: rect))
    }

    static func closedPath(_ points: [CGPoint]) -> Path {
        var path = Path()
        path.addLines(points)
        path.closeSubpath()
        return path
    }

    func points(in rect: CGRect, expansion: CGFloat = 0) -> [CGPoint] {
        let radius = min(31, min(rect.width, rect.height) / 2)
        let horizontal = rect.width - 2 * radius
        let vertical = rect.height - 2 * radius
        let quarter = CGFloat.pi * radius / 2
        let perimeter = 2 * (horizontal + vertical) + 4 * quarter
        guard perimeter > 0 else { return [] }

        let lobes = max(4, (perimeter / 113).rounded())
        var points: [CGPoint] = []
        var traveled: CGFloat = 0

        func sample(length: CGFloat, point: (CGFloat) -> (CGPoint, CGVector)) {
            guard length > 0 else { return }
            let steps = max(2, Int(ceil(length / 5)))
            for step in 0..<steps {
                let fraction = CGFloat(step) / CGFloat(steps)
                let progress = Double((traveled + length * fraction) / perimeter)
                let angle = progress * 2 * Double.pi
                let main = sin(angle * Double(lobes) - phase + Double(expansion) * 0.04)
                let secondary = sin(angle * Double(lobes + 3) + phase * 0.62) * 0.22
                let displacement = expansion + amplitude * (main + secondary)
                let (base, normal) = point(fraction)
                points.append(CGPoint(x: base.x + displacement * normal.dx,
                                      y: base.y + displacement * normal.dy))
            }
            traveled += length
        }

        func corner(x: CGFloat, y: CGFloat, from angle: CGFloat) {
            sample(length: quarter) { fraction in
                let turn = angle + fraction * .pi / 2
                let normal = CGVector(dx: cos(turn), dy: sin(turn))
                return (CGPoint(x: x + radius * normal.dx, y: y + radius * normal.dy), normal)
            }
        }

        sample(length: horizontal) { fraction in
            (CGPoint(x: rect.minX + radius + horizontal * fraction, y: rect.minY), CGVector(dx: 0, dy: -1))
        }
        corner(x: rect.maxX - radius, y: rect.minY + radius, from: -.pi / 2)
        sample(length: vertical) { fraction in
            (CGPoint(x: rect.maxX, y: rect.minY + radius + vertical * fraction), CGVector(dx: 1, dy: 0))
        }
        corner(x: rect.maxX - radius, y: rect.maxY - radius, from: 0)
        sample(length: horizontal) { fraction in
            (CGPoint(x: rect.maxX - radius - horizontal * fraction, y: rect.maxY), CGVector(dx: 0, dy: 1))
        }
        corner(x: rect.minX + radius, y: rect.maxY - radius, from: .pi / 2)
        sample(length: vertical) { fraction in
            (CGPoint(x: rect.minX, y: rect.maxY - radius - vertical * fraction), CGVector(dx: -1, dy: 0))
        }
        corner(x: rect.minX + radius, y: rect.minY + radius, from: .pi)
        return points
    }
}

struct HistoryWaveSource {
    let wave: HistoryWave
    let frame: CGRect
    let perspective: HistoryPerspective

    func projectedOutline(expansion: CGFloat = 0) -> [CGPoint] {
        wave.outline.points(in: frame, expansion: expansion).map {
            perspective.project($0, in: frame)
        }
    }

    fileprivate func fronts() -> [HistoryWaveFront] {
        return (0..<2).compactMap { strand in
            let pulse = wave.pulse(strand)
            let opacity = perspective.opacity * pulse.opacity
            guard opacity > 0.025 else { return nil }
            let points = projectedOutline(expansion: pulse.distance)
            let path = HistoryOutline.closedPath(points)
            return HistoryWaveFront(points: points, path: path, bounds: path.boundingRect,
                                    color: Palette.severity(wave.severity), opacity: opacity)
        }
    }
}

private struct HistoryWaveFront {
    let points: [CGPoint]
    let path: Path
    let bounds: CGRect
    let color: Color
    let opacity: Double

    func segments(in rect: CGRect) -> [HistoryWaveSegment] {
        guard let first = points.first else { return [] }
        return points.indices.compactMap { index in
            let end = index + 1 < points.count ? points[index + 1] : first
            let segment = HistoryWaveSegment(start: points[index], end: end)
            return segment.touches(rect) ? segment : nil
        }
    }
}

private struct HistoryWaveSegment {
    let start: CGPoint
    let end: CGPoint

    func touches(_ rect: CGRect) -> Bool {
        min(start.x, end.x) <= rect.maxX && max(start.x, end.x) >= rect.minX
            && min(start.y, end.y) <= rect.maxY && max(start.y, end.y) >= rect.minY
    }

    func intersection(with other: Self) -> CGPoint? {
        let dx = end.x - start.x
        let dy = end.y - start.y
        let otherDX = other.end.x - other.start.x
        let otherDY = other.end.y - other.start.y
        let determinant = dx * otherDY - dy * otherDX
        guard abs(determinant) > 0.001 else { return nil }

        let x = other.start.x - start.x
        let y = other.start.y - start.y
        let t = (x * otherDY - y * otherDX) / determinant
        let u = (x * dy - y * dx) / determinant
        guard (0...1).contains(t), (0...1).contains(u) else { return nil }
        return CGPoint(x: start.x + t * dx, y: start.y + t * dy)
    }
}

struct HistoryWaveField: View {
    let sources: [HistoryWaveSource]
    @Environment(\.colorScheme) private var scheme

    var body: some View {
        Canvas { context, size in
            let fronts = sources.map { $0.fronts() }
            // Keep neighboring crests out of each card's face as the cards fade into depth.
            var outsideCards = Path(CGRect(origin: .zero, size: size))
            for source in sources {
                outsideCards.addPath(HistoryOutline.closedPath(source.projectedOutline()))
            }
            var field = context
            field.clip(to: outsideCards, style: FillStyle(eoFill: true))
            var glow = field
            glow.addFilter(.blur(radius: 3))
            for group in fronts {
                for front in group {
                    glow.stroke(front.path, with: .color(front.color.opacity(front.opacity * 0.55)), lineWidth: 4)
                    field.stroke(front.path, with: .color(front.color.opacity(front.opacity)), lineWidth: 1.1)
                }
            }

            for (upper, lower) in zip(fronts, fronts.dropFirst()) {
                for first in upper {
                    for second in lower {
                        drawContacts(first, second, in: field)
                    }
                }
            }
        }
    }

    private func drawContacts(_ first: HistoryWaveFront, _ second: HistoryWaveFront, in context: GraphicsContext) {
        let overlap = first.bounds.intersection(second.bounds)
        guard !overlap.isNull, !overlap.isEmpty else { return }

        let upperSegments = first.segments(in: overlap)
        let lowerSegments = second.segments(in: overlap)
        let strength = min(first.opacity, second.opacity)
        for upper in upperSegments {
            for lower in lowerSegments {
                guard let point = upper.intersection(with: lower) else { continue }
                let radius = 2 + 7 * strength
                let halo = Path(ellipseIn: CGRect(x: point.x - radius, y: point.y - radius,
                                                  width: 2 * radius, height: 2 * radius))
                let center = scheme == .dark ? Color.white : second.color
                context.fill(halo, with: .radialGradient(
                    Gradient(colors: [center.opacity(strength), first.color.opacity(0)]),
                    center: point, startRadius: 0, endRadius: radius
                ))
            }
        }
    }
}

struct HeaderArtwork: View {
    let style: HeaderStyle
    var gifData: Data?
    var gifURL: URL?
    var reloadID: String?
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var gif: GIFFrames?

    var body: some View {
        GeometryReader { proxy in
            TimelineView(.animation(minimumInterval: 1.0 / 24, paused: reduceMotion)) { timeline in
                let time = reduceMotion ? 0 : timeline.date.timeIntervalSinceReferenceDate
                if style == .gif, let frame = gif?.frame(at: time) {
                    Image(uiImage: frame)
                        .resizable()
                        .scaledToFill()
                        .frame(width: proxy.size.width, height: proxy.size.height)
                        .clipped()
                        .opacity(0.58)
                } else {
                    ambient(time: time.truncatingRemainder(dividingBy: 400))
                }
            }
        }
        .mask {
            LinearGradient(stops: [.init(color: .clear, location: 0),
                                   .init(color: .black, location: 0.22),
                                   .init(color: .black, location: 0.65),
                                   .init(color: .clear, location: 1)],
                           startPoint: .top, endPoint: .bottom)
        }
        .task(id: (reloadID ?? "") + (reduceMotion ? "-quiet" : "-animated")) {
            gif = nil
            guard style == .gif else { return }
            let data = gifData
            let url = gifURL
            let still = reduceMotion
            let frames = await Task.detached(priority: .userInitiated) {
                GIFFrames(data: data, url: url, firstFrameOnly: still)
            }.value
            if !Task.isCancelled { gif = frames }
        }
        .accessibilityHidden(true)
    }

    private func ambient(time: Double) -> some View {
        Canvas { context, size in
            let orbit = style == .orbit
            let waves = style == .waves
            let tint = orbit ? Color.indigo : waves ? Color.cyan : Color(red: 0.32, green: 0.85, blue: 0.58)
            let center = CGPoint(x: size.width * 0.55, y: size.height * 0.56)
            let glow = Path(CGRect(origin: .zero, size: size))
            context.fill(glow, with: .radialGradient(Gradient(colors: [tint.opacity(0.49), tint.opacity(0.13), .clear]),
                                                      center: center, startRadius: 5, endRadius: size.width * 0.62))
            for index in 0..<16 {
                let row = Double(index)
                var path = Path()
                for step in 0...80 {
                    let progress = Double(step) / 80
                    let angle = progress * 2 * Double.pi
                    let y = size.height * (0.17 + row * 0.041)
                    let point: CGPoint
                    if orbit {
                        let radius = size.width * (0.10 + row * 0.027)
                        point = CGPoint(x: center.x + cos(angle + row * 0.13) * radius,
                                        y: center.y + sin(angle + row * 0.06) * radius * 0.48
                                            + cos(angle + time * 0.35) * row)
                    } else {
                        let amplitude = waves ? 18.0 : 32.0
                        point = CGPoint(x: size.width * progress,
                                        y: y + sin(angle * 1.2 + row * 0.39 + time * 0.42) * amplitude
                                            + cos(angle * 2.0 - row * 0.20 - time * 0.27) * (waves ? 7 : 24))
                    }
                    if step == 0 { path.move(to: point) } else { path.addLine(to: point) }
                    if step > 4, step % 17 == index % 17 {
                        let dot = CGRect(x: point.x - 1.1, y: point.y - 1.1, width: 2.2, height: 2.2)
                        context.fill(Path(ellipseIn: dot), with: .color(tint.opacity(0.76)))
                    }
                }
                context.stroke(path, with: .color(tint.opacity(0.14)), lineWidth: 5)
                context.stroke(path, with: .color(tint.opacity(0.67)), lineWidth: 0.7)
            }
        }
    }
}

struct GIFFrames: @unchecked Sendable {
    let images: [UIImage]
    let ends: [Double]

    static func isGIF(_ data: Data) -> Bool {
        guard let source = CGImageSourceCreateWithData(data as CFData, nil),
              let type = CGImageSourceGetType(source) else { return false }
        return (type as String) == UTType.gif.identifier && CGImageSourceGetCount(source) > 0
    }

    init?(data: Data?, url: URL?, firstFrameOnly: Bool) {
        guard let bytes = data ?? url.flatMap({ try? Data(contentsOf: $0) }),
              let source = CGImageSourceCreateWithData(bytes as CFData, nil) else { return nil }
        let count = CGImageSourceGetCount(source)
        var frames: [UIImage] = []
        var times: [Double] = []
        var elapsed = 0.0
        let interval = max(1, (count + 89) / 90)
        let options = [kCGImageSourceCreateThumbnailFromImageAlways: true,
                       kCGImageSourceThumbnailMaxPixelSize: 420] as [CFString: Any]
        for index in 0..<(firstFrameOnly ? min(1, count) : count) {
            let properties = CGImageSourceCopyPropertiesAtIndex(source, index, nil) as? [CFString: Any]
            let gif = properties?[kCGImagePropertyGIFDictionary] as? [CFString: Any]
            let duration = gif?[kCGImagePropertyGIFUnclampedDelayTime] as? Double
                ?? gif?[kCGImagePropertyGIFDelayTime] as? Double ?? 0.1
            if index % interval == 0,
               let image = CGImageSourceCreateThumbnailAtIndex(source, index, options as CFDictionary) {
                frames.append(UIImage(cgImage: image))
                times.append(elapsed)
            }
            elapsed += max(duration, 0.025)
            if !times.isEmpty { times[times.count - 1] = elapsed }
        }
        guard !frames.isEmpty else { return nil }
        images = frames
        ends = times
    }

    func frame(at time: Double) -> UIImage? {
        guard let duration = ends.last else { return nil }
        let position = time.truncatingRemainder(dividingBy: duration)
        return images[ends.firstIndex { $0 > position } ?? 0]
    }
}

struct SeveritySlider: View {
    @Binding var value: Int
    private let inset: CGFloat = 16

    var body: some View {
        VStack(spacing: 3) {
            GeometryReader { proxy in
                let width = max(1, proxy.size.width - inset * 2)
                let position = inset + width * Double(value) / 100
                ZStack(alignment: .leading) {
                    Capsule().fill(LinearGradient(colors: Palette.gradient, startPoint: .leading, endPoint: .trailing))
                        .frame(height: 12)
                    Circle().fill(Palette.severity(value))
                        .overlay(Circle().strokeBorder(.white, lineWidth: 3))
                        .shadow(color: .black.opacity(0.22), radius: 4, y: 2)
                        .frame(width: 29, height: 29)
                        .position(x: position, y: proxy.size.height / 2)
                }
                .frame(maxHeight: .infinity)
                .contentShape(Rectangle())
                .gesture(DragGesture(minimumDistance: 0).onChanged { drag in
                    value = Int((100 * min(max((drag.location.x - inset) / width, 0), 1)).rounded())
                })
            }
            .frame(height: 44)
            HStack {
                Text("Curada")
                Spacer()
                Text("Muy enferma")
            }
            .font(.caption)
            .foregroundStyle(.secondary)
            .accessibilityHidden(true)
        }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("Estado de la enfermedad")
        .accessibilityValue("\(Entry(severity: value).status), \(value) de 100")
        .accessibilityAdjustableAction { direction in
            switch direction {
            case .increment: value = min(100, value + 5)
            case .decrement: value = max(0, value - 5)
            @unknown default: break
            }
        }
    }
}
