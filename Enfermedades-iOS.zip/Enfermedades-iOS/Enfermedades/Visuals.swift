import SwiftUI
import UIKit
import ImageIO
import UniformTypeIdentifiers

enum Palette {
    static let colors: [(Double, Double, Double)] = [
        (0.15, 0.76, 0.38), (0.53, 0.77, 0.22), (0.91, 0.72, 0.17),
        (0.95, 0.43, 0.15), (0.89, 0.17, 0.25)
    ]
    static let gradient = colors.map { Color(red: $0.0, green: $0.1, blue: $0.2) }

    static func severity(_ value: Int) -> Color {
        let index = min(max(Double(value) / 25, 0), 4)
        let low = colors[Int(index)]
        let high = colors[min(Int(index) + 1, 4)]
        let fraction = index - floor(index)
        return Color(red: low.0 + (high.0 - low.0) * fraction,
                     green: low.1 + (high.1 - low.1) * fraction,
                     blue: low.2 + (high.2 - low.2) * fraction)
    }
}

struct EntryStatus: View {
    let entry: Entry
    let previous: Entry?

    var body: some View {
        ViewThatFits(in: .horizontal) {
            HStack(spacing: 10) {
                severityLabel
                evolutionLabel
            }
            VStack(alignment: .leading, spacing: 5) {
                severityLabel
                evolutionLabel
            }
        }
        .font(.caption.weight(.semibold))
        .accessibilityElement(children: .combine)
    }

    private var severityLabel: some View {
        Label {
            Text(entry.status)
        } icon: {
            Image(systemName: entry.severity == 0 ? "checkmark.circle.fill" : "waveform.path.ecg")
                .foregroundStyle(Palette.severity(entry.severity))
                .accessibilityHidden(true)
        }
    }

    @ViewBuilder
    private var evolutionLabel: some View {
        if let evolution = entry.evolution(since: previous) {
            Label(evolution.rawValue, systemImage: evolution.icon)
                .foregroundStyle(.secondary)
        }
    }
}

struct BubbleSurface: ViewModifier {
    var tint: Color? = nil
    var interactive = false
    var outline = HistoryOutline()
    @Environment(\.colorScheme) private var scheme

    func body(content: Content) -> some View {
        let shape = outline
        return content
            .background {
                if let tint {
                    shape.fill(LinearGradient(colors: [tint.opacity(scheme == .dark ? 0.38 : 0.27),
                                                        tint.opacity(0.09)], startPoint: .topLeading, endPoint: .bottomTrailing))
                }
            }
            .glassEffect(.regular.tint(tint?.opacity(0.20)).interactive(interactive), in: shape)
    }
}

struct HistoryWave {
    let severity: Int
    let time: TimeInterval
    let source: CGRect

    private var intensity: Double { Double(severity) / 100 }
    private var period: Double { 4.5 - 2.3 * intensity }
    var phase: Double { time * (1.35 + 2.4 * intensity) }
    var reach: CGFloat { 530 + 210 * intensity }
    var energy: CGFloat { 0.22 + 0.78 * intensity }
    var start: CGFloat { source.maxY - 12 }

    var outline: HistoryOutline {
        let amplitude = 1.05 + CGFloat(pow(intensity, 1.35)) * 7.2
        return HistoryOutline(top: amplitude, bottom: amplitude, side: amplitude * 0.65, phase: phase)
    }

    var fronts: [(y: CGFloat, opacity: Double)] {
        guard !source.isEmpty else { return [] }
        return (0..<3).map { index in
            let age = ((time / period) + Double(index) / 3).truncatingRemainder(dividingBy: 1)
            let fadeIn = min(age * 18, 1)
            return (start + reach * age, fadeIn * pow(1 - age, 2.2))
        }
    }

    func outline(at frame: CGRect) -> HistoryOutline {
        guard frame.minY < start + reach + 55 else { return HistoryOutline() }
        let pulses = fronts
        return HistoryOutline(
            top: displacement(at: frame.minY, pulses: pulses),
            bottom: displacement(at: frame.maxY, pulses: pulses),
            side: (displacement(at: frame.midY, across: 0.08, pulses: pulses)
                   + displacement(at: frame.midY, across: 0.92, pulses: pulses)) * 0.275,
            phase: phase - Double(frame.minY) * 0.018
        )
    }

    func height(of front: CGFloat, across progress: Double, band: Int = 0) -> CGFloat {
        let across = progress * 2 - 1
        let curve = pow(abs(across), 1.7) * (10 + Double(energy) * 28)
        let angle = progress * 12 + phase * 0.72 + Double(band) * 0.36
        let wobble = (sin(angle) + 0.34 * sin(angle * 1.72 - phase)) * (4 + Double(energy) * 14)
        return front - curve + wobble + CGFloat(band) * 7
    }

    private func displacement(at y: CGFloat, across progress: Double = 0.5,
                              pulses: [(y: CGFloat, opacity: Double)]) -> CGFloat {
        let amount = pulses.reduce(0.0) { sum, pulse in
            let distance = Double(y - height(of: pulse.y, across: progress))
            let envelope = exp(-pow(distance / 21, 2))
            return sum + sin(distance / 9) * envelope * pulse.opacity
        }
        return CGFloat(amount) * (2.6 + 3.9 * energy)
    }
}

struct HistoryOutline: Shape {
    var top: CGFloat = 0
    var bottom: CGFloat = 0
    var side: CGFloat = 0
    var phase: Double = 0

    func path(in rect: CGRect) -> Path {
        guard max(abs(top), abs(bottom), abs(side)) > 0.08 else {
            return RoundedRectangle(cornerRadius: 31, style: .circular).path(in: rect)
        }

        let radius = min(31, min(rect.width, rect.height) / 2)
        let start = CGPoint(x: rect.minX + radius, y: rect.minY)
        let topRight = CGPoint(x: rect.maxX - radius, y: rect.minY)
        let rightTop = CGPoint(x: rect.maxX, y: rect.minY + radius)
        let rightBottom = CGPoint(x: rect.maxX, y: rect.maxY - radius)
        let bottomRight = CGPoint(x: rect.maxX - radius, y: rect.maxY)
        let bottomLeft = CGPoint(x: rect.minX + radius, y: rect.maxY)
        let leftBottom = CGPoint(x: rect.minX, y: rect.maxY - radius)
        let leftTop = CGPoint(x: rect.minX, y: rect.minY + radius)

        var outline = Path()
        outline.move(to: start)
        addEdge(to: &outline, from: start, to: topRight, dx: 0, dy: -top, offset: 0)
        addCorner(to: &outline, from: topRight, through: CGPoint(x: rect.maxX, y: rect.minY), to: rightTop)
        addEdge(to: &outline, from: rightTop, to: rightBottom, dx: side, dy: 0, offset: 0.8)
        addCorner(to: &outline, from: rightBottom, through: CGPoint(x: rect.maxX, y: rect.maxY), to: bottomRight)
        addEdge(to: &outline, from: bottomRight, to: bottomLeft, dx: 0, dy: bottom, offset: 1.65)
        addCorner(to: &outline, from: bottomLeft, through: CGPoint(x: rect.minX, y: rect.maxY), to: leftBottom)
        addEdge(to: &outline, from: leftBottom, to: leftTop, dx: -side, dy: 0, offset: 2.4)
        addCorner(to: &outline, from: leftTop, through: CGPoint(x: rect.minX, y: rect.minY), to: start)
        outline.closeSubpath()
        return outline
    }

    private func addCorner(to path: inout Path, from start: CGPoint, through corner: CGPoint, to end: CGPoint) {
        let fraction: CGFloat = 0.55228475
        let first = CGPoint(x: start.x + (corner.x - start.x) * fraction,
                            y: start.y + (corner.y - start.y) * fraction)
        let second = CGPoint(x: end.x + (corner.x - end.x) * fraction,
                             y: end.y + (corner.y - end.y) * fraction)
        path.addCurve(to: end, control1: first, control2: second)
    }

    private func addEdge(to path: inout Path, from start: CGPoint, to end: CGPoint,
                         dx: CGFloat, dy: CGFloat, offset: Double) {
        for step in 1...28 {
            let fraction = Double(step) / 28
            let position = fraction * 2 * Double.pi
            let taper = pow(sin(fraction * Double.pi), 2)
            let first = sin(position * 1.7 + phase + offset)
            let second = sin(position * 2.9 - phase * 0.62 + offset) * 0.26
            let wave = CGFloat(taper * (first + second))
            path.addLine(to: CGPoint(x: start.x + (end.x - start.x) * fraction + dx * wave,
                                     y: start.y + (end.y - start.y) * fraction + dy * wave))
        }
    }
}

struct HistoryWaveField: View {
    let wave: HistoryWave

    var body: some View {
        Canvas { context, size in
            let color = Palette.severity(wave.severity)
            for front in wave.fronts where front.opacity > 0.01 && front.y < size.height + 40 {
                for band in -1...1 {
                    let alpha = front.opacity * (band == 0 ? 0.62 : 0.29)
                    var trace = Path()
                    for step in 0...56 {
                        let progress = Double(step) / 56
                        let point = CGPoint(x: size.width * progress,
                                            y: wave.height(of: front.y, across: progress, band: band))
                        if step == 0 { trace.move(to: point) } else { trace.addLine(to: point) }
                    }

                    let shimmer = Gradient(stops: [
                        .init(color: color.opacity(alpha * 0.12), location: 0),
                        .init(color: color.opacity(alpha), location: 0.16),
                        .init(color: color.opacity(alpha * 0.38), location: 0.5),
                        .init(color: color.opacity(alpha), location: 0.84),
                        .init(color: color.opacity(alpha * 0.12), location: 1)
                    ])
                    context.stroke(trace, with: .color(color.opacity(alpha * 0.12)), lineWidth: 6)
                    context.stroke(trace,
                                   with: .linearGradient(shimmer, startPoint: .zero,
                                                         endPoint: CGPoint(x: size.width, y: 0)),
                                   lineWidth: band == 0 ? 1.2 : 0.75)
                }
            }
        }
        .allowsHitTesting(false)
        .accessibilityHidden(true)
    }
}

struct HeaderArtwork: View {
    let style: HeaderStyle
    var gifData: Data?
    var gifURL: URL?
    var reloadID: String?
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var gif: GIFFrames?

    var body: some View {
        GeometryReader { proxy in
            TimelineView(.animation(minimumInterval: 1.0 / 24, paused: reduceMotion)) { timeline in
                let time = reduceMotion ? 0 : timeline.date.timeIntervalSinceReferenceDate
                if style == .gif, let frame = gif?.frame(at: time) {
                    Image(uiImage: frame)
                        .resizable()
                        .scaledToFill()
                        .frame(width: proxy.size.width, height: proxy.size.height)
                        .clipped()
                        .opacity(0.58)
                } else {
                    ambient(time: time.truncatingRemainder(dividingBy: 400))
                }
            }
        }
        .mask {
            LinearGradient(stops: [.init(color: .clear, location: 0),
                                   .init(color: .black, location: 0.22),
                                   .init(color: .black, location: 0.65),
                                   .init(color: .clear, location: 1)],
                           startPoint: .top, endPoint: .bottom)
        }
        .task(id: (reloadID ?? "") + (reduceMotion ? "-quiet" : "-animated")) {
            gif = nil
            guard style == .gif else { return }
            let data = gifData
            let url = gifURL
            let still = reduceMotion
            let frames = await Task.detached(priority: .userInitiated) {
                GIFFrames(data: data, url: url, firstFrameOnly: still)
            }.value
            if !Task.isCancelled { gif = frames }
        }
        .accessibilityHidden(true)
    }

    private func ambient(time: Double) -> some View {
        Canvas { context, size in
            let orbit = style == .orbit
            let waves = style == .waves
            let tint = orbit ? Color.indigo : waves ? Color.cyan : Color(red: 0.32, green: 0.85, blue: 0.58)
            let center = CGPoint(x: size.width * 0.55, y: size.height * 0.56)
            let glow = Path(CGRect(origin: .zero, size: size))
            context.fill(glow, with: .radialGradient(Gradient(colors: [tint.opacity(0.49), tint.opacity(0.13), .clear]),
                                                      center: center, startRadius: 5, endRadius: size.width * 0.62))
            for index in 0..<16 {
                let row = Double(index)
                var path = Path()
                for step in 0...80 {
                    let progress = Double(step) / 80
                    let angle = progress * 2 * Double.pi
                    let y = size.height * (0.17 + row * 0.041)
                    let point: CGPoint
                    if orbit {
                        let radius = size.width * (0.10 + row * 0.027)
                        point = CGPoint(x: center.x + cos(angle + row * 0.13) * radius,
                                        y: center.y + sin(angle + row * 0.06) * radius * 0.48
                                            + cos(angle + time * 0.35) * row)
                    } else {
                        let amplitude = waves ? 18.0 : 32.0
                        point = CGPoint(x: size.width * progress,
                                        y: y + sin(angle * 1.2 + row * 0.39 + time * 0.42) * amplitude
                                            + cos(angle * 2.0 - row * 0.20 - time * 0.27) * (waves ? 7 : 24))
                    }
                    if step == 0 { path.move(to: point) } else { path.addLine(to: point) }
                    if step > 4, step % 17 == index % 17 {
                        let dot = CGRect(x: point.x - 1.1, y: point.y - 1.1, width: 2.2, height: 2.2)
                        context.fill(Path(ellipseIn: dot), with: .color(tint.opacity(0.76)))
                    }
                }
                context.stroke(path, with: .color(tint.opacity(0.14)), lineWidth: 5)
                context.stroke(path, with: .color(tint.opacity(0.67)), lineWidth: 0.7)
            }
        }
    }
}

struct GIFFrames: @unchecked Sendable {
    let images: [UIImage]
    let ends: [Double]

    static func isGIF(_ data: Data) -> Bool {
        guard let source = CGImageSourceCreateWithData(data as CFData, nil),
              let type = CGImageSourceGetType(source) else { return false }
        return (type as String) == UTType.gif.identifier && CGImageSourceGetCount(source) > 0
    }

    init?(data: Data?, url: URL?, firstFrameOnly: Bool) {
        guard let bytes = data ?? url.flatMap({ try? Data(contentsOf: $0) }),
              let source = CGImageSourceCreateWithData(bytes as CFData, nil) else { return nil }
        let count = CGImageSourceGetCount(source)
        var frames: [UIImage] = []
        var times: [Double] = []
        var elapsed = 0.0
        let interval = max(1, (count + 89) / 90)
        let options = [kCGImageSourceCreateThumbnailFromImageAlways: true,
                       kCGImageSourceThumbnailMaxPixelSize: 420] as [CFString: Any]
        for index in 0..<(firstFrameOnly ? min(1, count) : count) {
            let properties = CGImageSourceCopyPropertiesAtIndex(source, index, nil) as? [CFString: Any]
            let gif = properties?[kCGImagePropertyGIFDictionary] as? [CFString: Any]
            let duration = gif?[kCGImagePropertyGIFUnclampedDelayTime] as? Double
                ?? gif?[kCGImagePropertyGIFDelayTime] as? Double ?? 0.1
            if index % interval == 0,
               let image = CGImageSourceCreateThumbnailAtIndex(source, index, options as CFDictionary) {
                frames.append(UIImage(cgImage: image))
                times.append(elapsed)
            }
            elapsed += max(duration, 0.025)
            if !times.isEmpty { times[times.count - 1] = elapsed }
        }
        guard !frames.isEmpty else { return nil }
        images = frames
        ends = times
    }

    func frame(at time: Double) -> UIImage? {
        guard let duration = ends.last else { return nil }
        let position = time.truncatingRemainder(dividingBy: duration)
        return images[ends.firstIndex { $0 > position } ?? 0]
    }
}

struct SeveritySlider: View {
    @Binding var value: Int
    private let inset: CGFloat = 16

    var body: some View {
        VStack(spacing: 3) {
            GeometryReader { proxy in
                let width = max(1, proxy.size.width - inset * 2)
                let position = inset + width * Double(value) / 100
                ZStack(alignment: .leading) {
                    Capsule().fill(LinearGradient(colors: Palette.gradient, startPoint: .leading, endPoint: .trailing))
                        .frame(height: 12)
                    Circle().fill(Palette.severity(value))
                        .overlay(Circle().strokeBorder(.white, lineWidth: 3))
                        .shadow(color: .black.opacity(0.22), radius: 4, y: 2)
                        .frame(width: 29, height: 29)
                        .position(x: position, y: proxy.size.height / 2)
                }
                .frame(maxHeight: .infinity)
                .contentShape(Rectangle())
                .gesture(DragGesture(minimumDistance: 0).onChanged { drag in
                    value = Int((100 * min(max((drag.location.x - inset) / width, 0), 1)).rounded())
                })
            }
            .frame(height: 44)
            HStack {
                Text("Curada")
                Spacer()
                Text("Muy enferma")
            }
            .font(.caption)
            .foregroundStyle(.secondary)
            .accessibilityHidden(true)
        }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("Estado de la enfermedad")
        .accessibilityValue("\(Entry(severity: value).status), \(value) de 100")
        .accessibilityAdjustableAction { direction in
            switch direction {
            case .increment: value = min(100, value + 5)
            case .decrement: value = max(0, value - 5)
            @unknown default: break
            }
        }
    }
}
