import SwiftUI
import UIKit
import ImageIO
import UniformTypeIdentifiers

enum Palette {
    static let colors: [(Double, Double, Double)] = [
        (0.15, 0.76, 0.38), (0.53, 0.77, 0.22), (0.91, 0.72, 0.17),
        (0.95, 0.43, 0.15), (0.89, 0.17, 0.25)
    ]
    static let gradient = colors.map { Color(red: $0.0, green: $0.1, blue: $0.2) }

    static func severity(_ value: Int) -> Color {
        let index = min(max(Double(value) / 25, 0), 4)
        let low = colors[Int(index)]
        let high = colors[min(Int(index) + 1, 4)]
        let fraction = index - floor(index)
        return Color(red: low.0 + (high.0 - low.0) * fraction,
                     green: low.1 + (high.1 - low.1) * fraction,
                     blue: low.2 + (high.2 - low.2) * fraction)
    }
}

struct EntryStatus: View {
    let entry: Entry
    let previous: Entry?

    var body: some View {
        ViewThatFits(in: .horizontal) {
            HStack(spacing: 10) {
                severityLabel
                evolutionLabel
            }
            VStack(alignment: .leading, spacing: 5) {
                severityLabel
                evolutionLabel
            }
        }
        .font(.caption.weight(.semibold))
        .accessibilityElement(children: .combine)
    }

    private var severityLabel: some View {
        Label {
            Text(entry.status)
        } icon: {
            Image(systemName: entry.severity == 0 ? "checkmark.circle.fill" : "waveform.path.ecg")
                .foregroundStyle(Palette.severity(entry.severity))
                .accessibilityHidden(true)
        }
    }

    @ViewBuilder
    private var evolutionLabel: some View {
        if let evolution = entry.evolution(since: previous) {
            Label(evolution.rawValue, systemImage: evolution.icon)
                .foregroundStyle(.secondary)
        }
    }
}

struct BubbleSurface: ViewModifier {
    var tint: Color? = nil
    var interactive = false
    var outline = HistoryOutline()
    @Environment(\.colorScheme) private var scheme

    func body(content: Content) -> some View {
        let shape = outline
        return content
            .background {
                if let tint {
                    shape.fill(LinearGradient(colors: [tint.opacity(scheme == .dark ? 0.38 : 0.27),
                                                        tint.opacity(0.09)], startPoint: .topLeading, endPoint: .bottomTrailing))
                }
            }
            .glassEffect(.regular.tint(tint?.opacity(0.20)).interactive(interactive), in: shape)
    }
}

struct HistoryWave {
    let severity: Int
    let time: TimeInterval

    private var intensity: Double { min(max(Double(severity) / 100, 0), 1) }
    private var period: Double { 5.4 - 1.9 * intensity }
    private var phase: Double { time * (0.86 + 0.72 * intensity) }
    private var reach: Double { 490 + 160 * intensity }

    var outline: HistoryOutline {
        HistoryOutline(amplitude: 0.5 + 3.25 * pow(intensity, 1.3), phase: phase)
    }

    func ribbon(_ index: Int, from origin: CGFloat) -> (center: CGFloat, spread: CGFloat, opacity: Double) {
        let age = (time / period + Double(index) / 3).truncatingRemainder(dividingBy: 1)
        let emergence = min(age * 11, 1)
        return (origin - 8 + reach * age, 4.2 + age * 4.4,
                emergence * pow(1 - age, 2.25) * (0.59 + 0.41 * intensity))
    }

    func offset(across progress: Double) -> CGFloat {
        let angle = progress * 2 * Double.pi
        let main = sin(angle * 1.12 - phase)
        let undertone = sin(angle * 1.9 - phase * 0.64 + 0.8) * 0.21
        return (main + undertone) * (7.5 + 7.5 * intensity)
    }
}

struct HistoryOutline: Shape {
    var amplitude: CGFloat = 0
    var phase: Double = 0

    func path(in rect: CGRect) -> Path {
        guard amplitude > 0 else {
            return RoundedRectangle(cornerRadius: 31, style: .circular).path(in: rect)
        }

        let radius = min(31, min(rect.width, rect.height) / 2)
        let topLeft = CGPoint(x: rect.minX + radius, y: rect.minY)
        let topRight = CGPoint(x: rect.maxX - radius, y: rect.minY)
        let rightTop = CGPoint(x: rect.maxX, y: rect.minY + radius)
        let rightBottom = CGPoint(x: rect.maxX, y: rect.maxY - radius)
        let bottomRight = CGPoint(x: rect.maxX - radius, y: rect.maxY)
        let bottomLeft = CGPoint(x: rect.minX + radius, y: rect.maxY)
        let leftBottom = CGPoint(x: rect.minX, y: rect.maxY - radius)
        let leftTop = CGPoint(x: rect.minX, y: rect.minY + radius)

        var outline = Path()
        outline.move(to: topLeft)
        addWave(to: &outline, from: topLeft, to: topRight, ripple: 0)
        addCorner(to: &outline, from: topRight, through: CGPoint(x: rect.maxX, y: rect.minY), to: rightTop)
        outline.addLine(to: rightBottom)
        addCorner(to: &outline, from: rightBottom, through: CGPoint(x: rect.maxX, y: rect.maxY), to: bottomRight)
        addWave(to: &outline, from: bottomRight, to: bottomLeft, ripple: 0.52)
        addCorner(to: &outline, from: bottomLeft, through: CGPoint(x: rect.minX, y: rect.maxY), to: leftBottom)
        outline.addLine(to: leftTop)
        addCorner(to: &outline, from: leftTop, through: CGPoint(x: rect.minX, y: rect.minY), to: topLeft)
        outline.closeSubpath()
        return outline
    }

    private func addCorner(to path: inout Path, from start: CGPoint, through corner: CGPoint, to end: CGPoint) {
        let fraction: CGFloat = 0.55228475
        let first = CGPoint(x: start.x + (corner.x - start.x) * fraction,
                            y: start.y + (corner.y - start.y) * fraction)
        let second = CGPoint(x: end.x + (corner.x - end.x) * fraction,
                             y: end.y + (corner.y - end.y) * fraction)
        path.addCurve(to: end, control1: first, control2: second)
    }

    private func addWave(to path: inout Path, from start: CGPoint, to end: CGPoint, ripple: Double) {
        for step in 1...48 {
            let fraction = Double(step) / 48
            let across = start.x <= end.x ? fraction : 1 - fraction
            let angle = across * 2.24 * Double.pi - phase + ripple
            let taper = sin(Double.pi * fraction)
            let offset = amplitude * taper * taper * sin(angle)
            path.addLine(to: CGPoint(x: start.x + (end.x - start.x) * fraction, y: start.y + offset))
        }
    }
}

struct HistoryWaveField: View {
    let wave: HistoryWave
    let origin: CGFloat

    var body: some View {
        Canvas { context, size in
            let color = Palette.severity(wave.severity)
            let curve = (0...60).map { wave.offset(across: Double($0) / 60) }
            for index in 0..<3 {
                let ribbon = wave.ribbon(index, from: origin)
                guard ribbon.opacity > 0.012, ribbon.center < size.height + 32 else { continue }

                for strand in -2...2 {
                    let strength = ribbon.opacity * (0.48 - Double(abs(strand)) * 0.11)
                    let center = ribbon.center + CGFloat(strand) * ribbon.spread
                    var trace = Path()
                    for (step, offset) in curve.enumerated() {
                        let point = CGPoint(x: size.width * Double(step) / 60, y: center + offset)
                        if step == 0 { trace.move(to: point) } else { trace.addLine(to: point) }
                    }

                    let glow = Gradient(stops: [
                        .init(color: color.opacity(0), location: 0),
                        .init(color: color.opacity(strength * 0.7), location: 0.12),
                        .init(color: color.opacity(strength), location: 0.5),
                        .init(color: color.opacity(strength * 0.7), location: 0.88),
                        .init(color: color.opacity(0), location: 1)
                    ])
                    let shade = GraphicsContext.Shading.linearGradient(
                        glow, startPoint: .zero, endPoint: CGPoint(x: size.width, y: 0)
                    )
                    if strand == 0 {
                        var blur = context
                        blur.addFilter(.blur(radius: 4))
                        blur.stroke(trace, with: shade, lineWidth: 4)
                    }
                    context.stroke(trace, with: shade, lineWidth: strand == 0 ? 1.1 : 0.7)
                }
            }
        }
        .allowsHitTesting(false)
        .accessibilityHidden(true)
    }
}

struct HeaderArtwork: View {
    let style: HeaderStyle
    var gifData: Data?
    var gifURL: URL?
    var reloadID: String?
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var gif: GIFFrames?

    var body: some View {
        GeometryReader { proxy in
            TimelineView(.animation(minimumInterval: 1.0 / 24, paused: reduceMotion)) { timeline in
                let time = reduceMotion ? 0 : timeline.date.timeIntervalSinceReferenceDate
                if style == .gif, let frame = gif?.frame(at: time) {
                    Image(uiImage: frame)
                        .resizable()
                        .scaledToFill()
                        .frame(width: proxy.size.width, height: proxy.size.height)
                        .clipped()
                        .opacity(0.58)
                } else {
                    ambient(time: time.truncatingRemainder(dividingBy: 400))
                }
            }
        }
        .mask {
            LinearGradient(stops: [.init(color: .clear, location: 0),
                                   .init(color: .black, location: 0.22),
                                   .init(color: .black, location: 0.65),
                                   .init(color: .clear, location: 1)],
                           startPoint: .top, endPoint: .bottom)
        }
        .task(id: (reloadID ?? "") + (reduceMotion ? "-quiet" : "-animated")) {
            gif = nil
            guard style == .gif else { return }
            let data = gifData
            let url = gifURL
            let still = reduceMotion
            let frames = await Task.detached(priority: .userInitiated) {
                GIFFrames(data: data, url: url, firstFrameOnly: still)
            }.value
            if !Task.isCancelled { gif = frames }
        }
        .accessibilityHidden(true)
    }

    private func ambient(time: Double) -> some View {
        Canvas { context, size in
            let orbit = style == .orbit
            let waves = style == .waves
            let tint = orbit ? Color.indigo : waves ? Color.cyan : Color(red: 0.32, green: 0.85, blue: 0.58)
            let center = CGPoint(x: size.width * 0.55, y: size.height * 0.56)
            let glow = Path(CGRect(origin: .zero, size: size))
            context.fill(glow, with: .radialGradient(Gradient(colors: [tint.opacity(0.49), tint.opacity(0.13), .clear]),
                                                      center: center, startRadius: 5, endRadius: size.width * 0.62))
            for index in 0..<16 {
                let row = Double(index)
                var path = Path()
                for step in 0...80 {
                    let progress = Double(step) / 80
                    let angle = progress * 2 * Double.pi
                    let y = size.height * (0.17 + row * 0.041)
                    let point: CGPoint
                    if orbit {
                        let radius = size.width * (0.10 + row * 0.027)
                        point = CGPoint(x: center.x + cos(angle + row * 0.13) * radius,
                                        y: center.y + sin(angle + row * 0.06) * radius * 0.48
                                            + cos(angle + time * 0.35) * row)
                    } else {
                        let amplitude = waves ? 18.0 : 32.0
                        point = CGPoint(x: size.width * progress,
                                        y: y + sin(angle * 1.2 + row * 0.39 + time * 0.42) * amplitude
                                            + cos(angle * 2.0 - row * 0.20 - time * 0.27) * (waves ? 7 : 24))
                    }
                    if step == 0 { path.move(to: point) } else { path.addLine(to: point) }
                    if step > 4, step % 17 == index % 17 {
                        let dot = CGRect(x: point.x - 1.1, y: point.y - 1.1, width: 2.2, height: 2.2)
                        context.fill(Path(ellipseIn: dot), with: .color(tint.opacity(0.76)))
                    }
                }
                context.stroke(path, with: .color(tint.opacity(0.14)), lineWidth: 5)
                context.stroke(path, with: .color(tint.opacity(0.67)), lineWidth: 0.7)
            }
        }
    }
}

struct GIFFrames: @unchecked Sendable {
    let images: [UIImage]
    let ends: [Double]

    static func isGIF(_ data: Data) -> Bool {
        guard let source = CGImageSourceCreateWithData(data as CFData, nil),
              let type = CGImageSourceGetType(source) else { return false }
        return (type as String) == UTType.gif.identifier && CGImageSourceGetCount(source) > 0
    }

    init?(data: Data?, url: URL?, firstFrameOnly: Bool) {
        guard let bytes = data ?? url.flatMap({ try? Data(contentsOf: $0) }),
              let source = CGImageSourceCreateWithData(bytes as CFData, nil) else { return nil }
        let count = CGImageSourceGetCount(source)
        var frames: [UIImage] = []
        var times: [Double] = []
        var elapsed = 0.0
        let interval = max(1, (count + 89) / 90)
        let options = [kCGImageSourceCreateThumbnailFromImageAlways: true,
                       kCGImageSourceThumbnailMaxPixelSize: 420] as [CFString: Any]
        for index in 0..<(firstFrameOnly ? min(1, count) : count) {
            let properties = CGImageSourceCopyPropertiesAtIndex(source, index, nil) as? [CFString: Any]
            let gif = properties?[kCGImagePropertyGIFDictionary] as? [CFString: Any]
            let duration = gif?[kCGImagePropertyGIFUnclampedDelayTime] as? Double
                ?? gif?[kCGImagePropertyGIFDelayTime] as? Double ?? 0.1
            if index % interval == 0,
               let image = CGImageSourceCreateThumbnailAtIndex(source, index, options as CFDictionary) {
                frames.append(UIImage(cgImage: image))
                times.append(elapsed)
            }
            elapsed += max(duration, 0.025)
            if !times.isEmpty { times[times.count - 1] = elapsed }
        }
        guard !frames.isEmpty else { return nil }
        images = frames
        ends = times
    }

    func frame(at time: Double) -> UIImage? {
        guard let duration = ends.last else { return nil }
        let position = time.truncatingRemainder(dividingBy: duration)
        return images[ends.firstIndex { $0 > position } ?? 0]
    }
}

struct SeveritySlider: View {
    @Binding var value: Int
    private let inset: CGFloat = 16

    var body: some View {
        VStack(spacing: 3) {
            GeometryReader { proxy in
                let width = max(1, proxy.size.width - inset * 2)
                let position = inset + width * Double(value) / 100
                ZStack(alignment: .leading) {
                    Capsule().fill(LinearGradient(colors: Palette.gradient, startPoint: .leading, endPoint: .trailing))
                        .frame(height: 12)
                    Circle().fill(Palette.severity(value))
                        .overlay(Circle().strokeBorder(.white, lineWidth: 3))
                        .shadow(color: .black.opacity(0.22), radius: 4, y: 2)
                        .frame(width: 29, height: 29)
                        .position(x: position, y: proxy.size.height / 2)
                }
                .frame(maxHeight: .infinity)
                .contentShape(Rectangle())
                .gesture(DragGesture(minimumDistance: 0).onChanged { drag in
                    value = Int((100 * min(max((drag.location.x - inset) / width, 0), 1)).rounded())
                })
            }
            .frame(height: 44)
            HStack {
                Text("Curada")
                Spacer()
                Text("Muy enferma")
            }
            .font(.caption)
            .foregroundStyle(.secondary)
            .accessibilityHidden(true)
        }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("Estado de la enfermedad")
        .accessibilityValue("\(Entry(severity: value).status), \(value) de 100")
        .accessibilityAdjustableAction { direction in
            switch direction {
            case .increment: value = min(100, value + 5)
            case .decrement: value = max(0, value - 5)
            @unknown default: break
            }
        }
    }
}
