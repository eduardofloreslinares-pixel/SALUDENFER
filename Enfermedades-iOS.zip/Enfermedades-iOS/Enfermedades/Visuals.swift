import SwiftUI
import UIKit
import ImageIO
import UniformTypeIdentifiers

enum Palette {
    static let colors: [(Double, Double, Double)] = [
        (0.15, 0.76, 0.38), (0.53, 0.77, 0.22), (0.91, 0.72, 0.17),
        (0.95, 0.43, 0.15), (0.89, 0.17, 0.25)
    ]
    static let gradient = colors.map { Color(red: $0.0, green: $0.1, blue: $0.2) }

    static func severity(_ value: Int) -> Color {
        let index = min(max(Double(value) / 25, 0), 4)
        let low = colors[Int(index)]
        let high = colors[min(Int(index) + 1, 4)]
        let fraction = index - floor(index)
        return Color(red: low.0 + (high.0 - low.0) * fraction,
                     green: low.1 + (high.1 - low.1) * fraction,
                     blue: low.2 + (high.2 - low.2) * fraction)
    }
}

struct EntryStatus: View {
    let entry: Entry
    let previous: Entry?

    var body: some View {
        ViewThatFits(in: .horizontal) {
            HStack(spacing: 10) {
                severityLabel
                evolutionLabel
            }
            VStack(alignment: .leading, spacing: 5) {
                severityLabel
                evolutionLabel
            }
        }
        .font(.caption.weight(.semibold))
        .accessibilityElement(children: .combine)
    }

    private var severityLabel: some View {
        Label {
            Text(entry.status)
        } icon: {
            Image(systemName: entry.severity == 0 ? "checkmark.circle.fill" : "waveform.path.ecg")
                .foregroundStyle(Palette.severity(entry.severity))
                .accessibilityHidden(true)
        }
    }

    @ViewBuilder
    private var evolutionLabel: some View {
        if let evolution = entry.evolution(since: previous) {
            Label(evolution.rawValue, systemImage: evolution.icon)
                .foregroundStyle(.secondary)
        }
    }
}

struct BubbleSurface: ViewModifier {
    var tint: Color? = nil
    var interactive = false
    @Environment(\.colorScheme) private var scheme

    func body(content: Content) -> some View {
        let shape = RoundedRectangle(cornerRadius: 31)
        return content
            .background {
                if let tint {
                    shape.fill(LinearGradient(colors: [tint.opacity(scheme == .dark ? 0.38 : 0.27),
                                                        tint.opacity(0.09)], startPoint: .topLeading, endPoint: .bottomTrailing))
                }
            }
            .glassEffect(.regular.tint(tint?.opacity(0.20)).interactive(interactive), in: shape)
    }
}

struct HeaderArtwork: View {
    let style: HeaderStyle
    var gifData: Data?
    var gifURL: URL?
    var reloadID: String?
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var gif: GIFFrames?

    var body: some View {
        GeometryReader { proxy in
            TimelineView(.animation(minimumInterval: 1.0 / 24, paused: reduceMotion)) { timeline in
                let time = reduceMotion ? 0 : timeline.date.timeIntervalSinceReferenceDate
                if style == .gif, let frame = gif?.frame(at: time) {
                    Image(uiImage: frame)
                        .resizable()
                        .scaledToFill()
                        .frame(width: proxy.size.width, height: proxy.size.height)
                        .clipped()
                        .opacity(0.58)
                } else {
                    ambient(time: time.truncatingRemainder(dividingBy: 400))
                }
            }
        }
        .mask {
            LinearGradient(stops: [.init(color: .clear, location: 0),
                                   .init(color: .black, location: 0.22),
                                   .init(color: .black, location: 0.65),
                                   .init(color: .clear, location: 1)],
                           startPoint: .top, endPoint: .bottom)
        }
        .task(id: (reloadID ?? "") + (reduceMotion ? "-quiet" : "-animated")) {
            gif = nil
            guard style == .gif else { return }
            let data = gifData
            let url = gifURL
            let still = reduceMotion
            let frames = await Task.detached(priority: .userInitiated) {
                GIFFrames(data: data, url: url, firstFrameOnly: still)
            }.value
            if !Task.isCancelled { gif = frames }
        }
        .accessibilityHidden(true)
    }

    private func ambient(time: Double) -> some View {
        Canvas { context, size in
            let orbit = style == .orbit
            let waves = style == .waves
            let tint = orbit ? Color.indigo : waves ? Color.cyan : Color(red: 0.32, green: 0.85, blue: 0.58)
            let center = CGPoint(x: size.width * 0.55, y: size.height * 0.56)
            let glow = Path(CGRect(origin: .zero, size: size))
            context.fill(glow, with: .radialGradient(Gradient(colors: [tint.opacity(0.49), tint.opacity(0.13), .clear]),
                                                      center: center, startRadius: 5, endRadius: size.width * 0.62))
            for index in 0..<16 {
                let row = Double(index)
                var path = Path()
                for step in 0...80 {
                    let progress = Double(step) / 80
                    let angle = progress * 2 * Double.pi
                    let y = size.height * (0.17 + row * 0.041)
                    let point: CGPoint
                    if orbit {
                        let radius = size.width * (0.10 + row * 0.027)
                        point = CGPoint(x: center.x + cos(angle + row * 0.13) * radius,
                                        y: center.y + sin(angle + row * 0.06) * radius * 0.48
                                            + cos(angle + time * 0.35) * row)
                    } else {
                        let amplitude = waves ? 18.0 : 32.0
                        point = CGPoint(x: size.width * progress,
                                        y: y + sin(angle * 1.2 + row * 0.39 + time * 0.42) * amplitude
                                            + cos(angle * 2.0 - row * 0.20 - time * 0.27) * (waves ? 7 : 24))
                    }
                    if step == 0 { path.move(to: point) } else { path.addLine(to: point) }
                    if step > 4, step % 17 == index % 17 {
                        let dot = CGRect(x: point.x - 1.1, y: point.y - 1.1, width: 2.2, height: 2.2)
                        context.fill(Path(ellipseIn: dot), with: .color(tint.opacity(0.76)))
                    }
                }
                context.stroke(path, with: .color(tint.opacity(0.14)), lineWidth: 5)
                context.stroke(path, with: .color(tint.opacity(0.67)), lineWidth: 0.7)
            }
        }
    }
}

struct GIFFrames: @unchecked Sendable {
    let images: [UIImage]
    let ends: [Double]

    static func isGIF(_ data: Data) -> Bool {
        guard let source = CGImageSourceCreateWithData(data as CFData, nil),
              let type = CGImageSourceGetType(source) else { return false }
        return (type as String) == UTType.gif.identifier && CGImageSourceGetCount(source) > 0
    }

    init?(data: Data?, url: URL?, firstFrameOnly: Bool) {
        guard let bytes = data ?? url.flatMap({ try? Data(contentsOf: $0) }),
              let source = CGImageSourceCreateWithData(bytes as CFData, nil) else { return nil }
        let count = CGImageSourceGetCount(source)
        var frames: [UIImage] = []
        var times: [Double] = []
        var elapsed = 0.0
        let interval = max(1, (count + 89) / 90)
        let options = [kCGImageSourceCreateThumbnailFromImageAlways: true,
                       kCGImageSourceThumbnailMaxPixelSize: 420] as [CFString: Any]
        for index in 0..<(firstFrameOnly ? min(1, count) : count) {
            let properties = CGImageSourceCopyPropertiesAtIndex(source, index, nil) as? [CFString: Any]
            let gif = properties?[kCGImagePropertyGIFDictionary] as? [CFString: Any]
            let duration = gif?[kCGImagePropertyGIFUnclampedDelayTime] as? Double
                ?? gif?[kCGImagePropertyGIFDelayTime] as? Double ?? 0.1
            if index % interval == 0,
               let image = CGImageSourceCreateThumbnailAtIndex(source, index, options as CFDictionary) {
                frames.append(UIImage(cgImage: image))
                times.append(elapsed)
            }
            elapsed += max(duration, 0.025)
            if !times.isEmpty { times[times.count - 1] = elapsed }
        }
        guard !frames.isEmpty else { return nil }
        images = frames
        ends = times
    }

    func frame(at time: Double) -> UIImage? {
        guard let duration = ends.last else { return nil }
        let position = time.truncatingRemainder(dividingBy: duration)
        return images[ends.firstIndex { $0 > position } ?? 0]
    }
}

struct SeveritySlider: View {
    @Binding var value: Int
    private let inset: CGFloat = 16

    var body: some View {
        VStack(spacing: 3) {
            GeometryReader { proxy in
                let width = max(1, proxy.size.width - inset * 2)
                let position = inset + width * Double(value) / 100
                ZStack(alignment: .leading) {
                    Capsule().fill(LinearGradient(colors: Palette.gradient, startPoint: .leading, endPoint: .trailing))
                        .frame(height: 12)
                    Circle().fill(Palette.severity(value))
                        .overlay(Circle().strokeBorder(.white, lineWidth: 3))
                        .shadow(color: .black.opacity(0.22), radius: 4, y: 2)
                        .frame(width: 29, height: 29)
                        .position(x: position, y: proxy.size.height / 2)
                }
                .frame(maxHeight: .infinity)
                .contentShape(Rectangle())
                .gesture(DragGesture(minimumDistance: 0).onChanged { drag in
                    value = Int((100 * min(max((drag.location.x - inset) / width, 0), 1)).rounded())
                })
            }
            .frame(height: 44)
            HStack {
                Text("Curada")
                Spacer()
                Text("Muy enferma")
            }
            .font(.caption)
            .foregroundStyle(.secondary)
            .accessibilityHidden(true)
        }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("Estado de la enfermedad")
        .accessibilityValue("\(Entry(severity: value).status), \(value) de 100")
        .accessibilityAdjustableAction { direction in
            switch direction {
            case .increment: value = min(100, value + 5)
            case .decrement: value = max(0, value - 5)
            @unknown default: break
            }
        }
    }
}
