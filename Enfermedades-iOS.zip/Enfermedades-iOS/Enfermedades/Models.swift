import Foundation
import Observation

struct Illness: Codable, Identifiable {
    var id = UUID()
    var name = ""
    var summary = ""
    var animation: HeaderStyle = .aurora
    var gif: String?
    var artwork: Int?
    var animatedArtwork: Bool?
    var created = Date()
    var entries: [Entry] = []

    var updated: Date { max(entries.first?.created ?? created, created) }
    var illustration: Int {
        artwork ?? name.utf16.reduce(0) { ($0 + Int($1)) % 12 }
    }
    var showsAnimatedArtwork: Bool { animatedArtwork ?? (animation == .gif && gif != nil) }

    func statusBefore(_ entry: Entry) -> Entry? {
        entries.first { $0.kind == .status && $0.id != entry.id && $0.created <= entry.created }
    }

    mutating func put(_ entry: Entry) {
        entries.removeAll { $0.id == entry.id }
        entries.insert(entry, at: 0)
        entries.sort { $0.created > $1.created }
    }
}

enum HeaderStyle: String, Codable, CaseIterable, Identifiable {
    case aurora, waves, orbit, gif
    var id: String { rawValue }
    var label: String {
        switch self {
        case .aurora: "Aurora"
        case .waves: "Ondas"
        case .orbit: "Órbita"
        case .gif: "Mi GIF"
        }
    }
    var icon: String {
        switch self {
        case .aurora: "sparkles"
        case .waves: "waveform.path"
        case .orbit: "circle.hexagongrid"
        case .gif: "photo.on.rectangle"
        }
    }
}

struct Entry: Codable, Identifiable {
    var id = UUID()
    var title = ""
    var notes = ""
    var created = Date()
    var severity = 55
    var photos: [String] = []
    var health: [HealthAttachment] = []
    var recordKind: RecordKind?
    var diseaseState: DiseaseState?

    var kind: RecordKind { recordKind ?? .status }
    var hasNotes: Bool { kind == .note || !notes.isEmpty || !photos.isEmpty }
    var displayTitle: String {
        guard title.isEmpty else { return title }
        switch kind {
        case .status: return diseaseState?.label ?? status
        case .note: return "Nota de seguimiento"
        case .attachments: return health.isEmpty ? "Adjuntos" : health.map(\.name).joined(separator: ", ")
        }
    }

    var status: String {
        switch severity {
        case 0: "Curada"
        case 1...24: "Leve"
        case 25...59: "Moderada"
        case 60...94: "Fuerte"
        default: "Muy fuerte"
        }
    }

    func evolution(since previous: Entry?) -> EntryEvolution? {
        guard severity > 0, let previous else { return nil }
        if previous.severity == 0 { return .relapse }
        switch severity - previous.severity {
        case ..<(-14): return severity <= 24 ? .recovering : .improving
        case -14 ... -1: return .slightImprovement
        case 0: return .stable
        case 1...14: return .slightWorsening
        default: return .worsening
        }
    }
}

enum RecordKind: String, Codable, CaseIterable, Identifiable {
    case status, note, attachments
    var id: Self { self }
    var label: String {
        switch self {
        case .status: "Estado de la enfermedad"
        case .note: "Nota de seguimiento"
        case .attachments: "Síntomas y medicamentos"
        }
    }
}

enum DiseaseState: String, Codable, CaseIterable, Identifiable {
    case active, worsening, improving, recovering, recovered
    var id: Self { self }
    var label: String {
        switch self {
        case .active: "En curso"
        case .worsening: "Empeoramiento"
        case .improving: "Mejorando"
        case .recovering: "Recuperándose"
        case .recovered: "Recuperada"
        }
    }
    var icon: String {
        switch self {
        case .active: "clock"
        case .worsening: "waveform.path.ecg"
        case .improving: "arrow.down.right"
        case .recovering: "sparkle"
        case .recovered: "checkmark"
        }
    }

    static func inferred(from entry: Entry, since previous: Entry?) -> Self {
        if let state = entry.diseaseState { return state }
        if entry.severity == 0 { return .recovered }
        switch entry.evolution(since: previous) {
        case .recovering: return .recovering
        case .improving, .slightImprovement: return .improving
        case .worsening, .slightWorsening: return .worsening
        default: return .active
        }
    }
}

struct DiseaseHistory {
    struct Status {
        let date: Date
        let state: DiseaseState
    }

    let calendar: Calendar
    let today: Date
    let start: Date
    let entries: [Entry]
    let byDay: [Date: [Entry]]
    private let statuses: [Status]
    private let statesByEntry: [Entry.ID: DiseaseState]

    init(illness: Illness, calendar: Calendar = .current, now: Date = .now) {
        self.calendar = calendar
        today = calendar.startOfDay(for: now)
        entries = illness.entries
        byDay = Dictionary(grouping: illness.entries) { calendar.startOfDay(for: $0.created) }
        let explicit = illness.entries.filter { $0.kind == .status }.reversed()
        let startTime = min(illness.created, explicit.first?.created ?? illness.created)
        start = calendar.startOfDay(for: startTime)

        var history = [Status(date: startTime, state: .active)]
        var resolved: [Entry.ID: DiseaseState] = [:]
        var previous: Entry?
        for entry in explicit {
            let state = DiseaseState.inferred(from: entry, since: previous)
            history.append(Status(date: entry.created, state: state))
            resolved[entry.id] = state
            previous = entry
        }
        statuses = history
        statesByEntry = resolved
    }

    func day(_ date: Date) -> Date { calendar.startOfDay(for: date) }
    func shift(_ date: Date, by days: Int) -> Date {
        calendar.date(byAdding: .day, value: days, to: date) ?? date
    }
    func records(_ date: Date) -> [Entry] { byDay[day(date), default: []] }
    func state(for entry: Entry) -> DiseaseState { statesByEntry[entry.id] ?? .active }

    func entryTime(on date: Date, now: Date = .now) -> Date {
        if day(date) == day(now) { return now }
        return calendar.date(bySettingHour: calendar.component(.hour, from: now),
                      minute: calendar.component(.minute, from: now),
                      second: 0, of: day(date)).map { min($0, now) } ?? now
    }

    func attachmentTime(on date: Date, now: Date = .now) -> Date? {
        let day = self.day(date)
        guard day <= today else { return nil }
        let proposed = entryTime(on: day, now: now)
        if allowsAttachments(at: proposed) { return proposed }
        let end = min(shift(day, by: 1), now)
        for index in statuses.indices.reversed() where statuses[index].state != .recovered {
            let first = max(day, statuses[index].date)
            let nextIndex = index + 1
            let last = nextIndex < statuses.count ? min(end, statuses[nextIndex].date) : end
            if first < last { return first }
        }
        return nil
    }

    func status(on date: Date) -> Status? {
        let day = self.day(date)
        guard day <= today else { return nil }
        return statuses.last { $0.date < shift(day, by: 1) }
    }
    func marker(on date: Date) -> DiseaseState? {
        guard let status = status(on: date) else { return nil }
        if status.state == .recovered && day(status.date) != day(date) { return nil }
        return status.state
    }
    func allowsAttachments(at date: Date) -> Bool {
        guard day(date) <= today,
              let status = statuses.last(where: { $0.date <= date }) else { return false }
        return status.state != .recovered
    }
    var cardDay: Date {
        guard let status = status(on: today), status.state == .recovered else { return today }
        return day(status.date)
    }
    var daysTracked: Int {
        max(1, (calendar.dateComponents([.day], from: start, to: cardDay).day ?? 0) + 1)
    }
}

enum EntryEvolution: String {
    case recovering = "Recuperándose"
    case improving = "Mejorando"
    case slightImprovement = "Leve mejoría"
    case stable = "Sin cambios"
    case slightWorsening = "Leve empeoramiento"
    case worsening = "Empeorando"
    case relapse = "Reapareció"

    var icon: String {
        switch self {
        case .recovering, .improving, .slightImprovement: "arrow.down.right"
        case .stable: "minus"
        case .slightWorsening, .worsening: "arrow.up.right"
        case .relapse: "arrow.counterclockwise"
        }
    }
}

enum HealthKind: String, Codable, CaseIterable, Identifiable {
    case symptom, medication
    var id: String { rawValue }
    var title: String { self == .symptom ? "Síntomas" : "Medicamentos" }
    var singular: String { self == .symptom ? "Síntoma" : "Medicamento" }
    var icon: String { self == .symptom ? "waveform.path.ecg" : "pills" }
}

struct HealthAttachment: Codable, Identifiable, Equatable {
    var id: String = UUID().uuidString
    var kind: HealthKind
    var name: String
    var detail: String = ""
    var date: Date?
    var fromHealth = false
}

@MainActor @Observable
final class Journal {
    private(set) var illnesses: [Illness] = []
    private(set) var loadError: String?
    private let folder = URL.applicationSupportDirectory.appending(path: "Enfermedades", directoryHint: .isDirectory)
    private var records: URL { folder.appending(path: "journal.json") }

    init() {
        do {
            try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
            try FileManager.default.setAttributes([.protectionKey: FileProtectionType.complete], ofItemAtPath: folder.path)
            var privateFolder = folder
            var values = URLResourceValues()
            values.isExcludedFromBackup = true
            try privateFolder.setResourceValues(values)
            if FileManager.default.fileExists(atPath: records.path) {
                illnesses = try JSONDecoder().decode([Illness].self, from: Data(contentsOf: records))
            }
            removeUnusedMedia()
        } catch {
            loadError = error.localizedDescription
        }
    }

    func illness(_ id: UUID) -> Illness? { illnesses.first { $0.id == id } }

    func media(_ name: String) -> URL { folder.appending(path: name) }

    func save(_ illness: Illness, media staged: [String: Data] = [:]) throws {
        guard loadError == nil else { throw CocoaError(.fileReadCorruptFile) }
        var updated = illnesses.filter { $0.id != illness.id }
        updated.append(illness)
        updated.sort { $0.updated > $1.updated }
        var written: [URL] = []
        do {
            for (name, data) in staged {
                let url = media(name)
                try data.write(to: url, options: [.atomic, .completeFileProtection])
                written.append(url)
            }
            try JSONEncoder().encode(updated).write(to: records, options: [.atomic, .completeFileProtection])
        } catch {
            for url in written { try? FileManager.default.removeItem(at: url) }
            throw error
        }
        illnesses = updated
        removeUnusedMedia()
    }

    private func removeUnusedMedia() {
        let used = Set(illnesses.flatMap { illness in
            [illness.gif].compactMap { $0 } + illness.entries.flatMap(\.photos)
        })
        guard let files = try? FileManager.default.contentsOfDirectory(at: folder, includingPropertiesForKeys: nil) else { return }
        for url in files where ["gif", "jpg"].contains(url.pathExtension) && !used.contains(url.lastPathComponent) {
            try? FileManager.default.removeItem(at: url)
        }
    }
}

extension String {
    var trimmed: String { trimmingCharacters(in: .whitespacesAndNewlines) }
}
