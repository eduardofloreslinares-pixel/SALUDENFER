import Foundation
import Observation

struct Illness: Codable, Identifiable {
    var id = UUID()
    var name = ""
    var summary = ""
    var animation: HeaderStyle = .aurora
    var gif: String?
    var created = Date()
    var entries: [Entry] = []

    var latest: Entry? { entries.first }
    var lastActive: Entry? { entries.first { $0.severity > 0 } }
    var updated: Date { latest?.created ?? created }

    mutating func put(_ entry: Entry) {
        entries.removeAll { $0.id == entry.id }
        entries.append(entry)
        entries.sort { $0.created > $1.created }
    }
}

enum HeaderStyle: String, Codable, CaseIterable, Identifiable {
    case aurora, waves, orbit, gif
    var id: String { rawValue }
    var label: String {
        switch self {
        case .aurora: "Aurora"
        case .waves: "Ondas"
        case .orbit: "Órbita"
        case .gif: "Mi GIF"
        }
    }
    var icon: String {
        switch self {
        case .aurora: "sparkles"
        case .waves: "waveform.path"
        case .orbit: "circle.hexagongrid"
        case .gif: "photo.on.rectangle"
        }
    }
}

struct Entry: Codable, Identifiable {
    var id = UUID()
    var title = ""
    var notes = ""
    var created = Date()
    var severity = 55
    var photos: [String] = []
    var health: [HealthAttachment] = []

    var status: String {
        switch severity {
        case 0: "Curada"
        case 1...24: "Recuperándose"
        case 25...49: "Leve"
        case 50...74: "En curso"
        case 75...99: "Fuerte"
        default: "Muy enferma"
        }
    }
}

enum HealthKind: String, Codable, CaseIterable, Identifiable {
    case symptom, medication
    var id: String { rawValue }
    var title: String { self == .symptom ? "Síntomas" : "Medicamentos" }
    var singular: String { self == .symptom ? "Síntoma" : "Medicamento" }
    var icon: String { self == .symptom ? "waveform.path.ecg" : "pills" }
}

struct HealthAttachment: Codable, Identifiable, Equatable {
    var id: String = UUID().uuidString
    var kind: HealthKind
    var name: String
    var detail: String = ""
    var date: Date?
    var fromHealth = false
}

@MainActor @Observable
final class Journal {
    private(set) var illnesses: [Illness] = []
    private(set) var loadError: String?
    private let folder = URL.applicationSupportDirectory.appending(path: "Enfermedades", directoryHint: .isDirectory)
    private var records: URL { folder.appending(path: "journal.json") }

    init() {
        do {
            try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
            try FileManager.default.setAttributes([.protectionKey: FileProtectionType.complete], ofItemAtPath: folder.path)
            var privateFolder = folder
            var values = URLResourceValues()
            values.isExcludedFromBackup = true
            try privateFolder.setResourceValues(values)
            if FileManager.default.fileExists(atPath: records.path) {
                illnesses = try JSONDecoder().decode([Illness].self, from: Data(contentsOf: records))
            }
            removeUnusedMedia()
        } catch {
            loadError = error.localizedDescription
        }
    }

    func illness(_ id: UUID) -> Illness? { illnesses.first { $0.id == id } }

    func media(_ name: String) -> URL { folder.appending(path: name) }

    func save(_ illness: Illness, media staged: [String: Data] = [:]) throws {
        guard loadError == nil else { throw CocoaError(.fileReadCorruptFile) }
        var updated = illnesses.filter { $0.id != illness.id }
        updated.append(illness)
        updated.sort { $0.updated > $1.updated }
        var written: [URL] = []
        do {
            for (name, data) in staged {
                let url = media(name)
                try data.write(to: url, options: [.atomic, .completeFileProtection])
                written.append(url)
            }
            try JSONEncoder().encode(updated).write(to: records, options: [.atomic, .completeFileProtection])
        } catch {
            for url in written { try? FileManager.default.removeItem(at: url) }
            throw error
        }
        illnesses = updated
        removeUnusedMedia()
    }

    private func removeUnusedMedia() {
        let used = Set(illnesses.flatMap { illness in
            [illness.gif].compactMap { $0 } + illness.entries.flatMap(\.photos)
        })
        guard let files = try? FileManager.default.contentsOfDirectory(at: folder, includingPropertiesForKeys: nil) else { return }
        for url in files where ["gif", "jpg"].contains(url.pathExtension) && !used.contains(url.lastPathComponent) {
            try? FileManager.default.removeItem(at: url)
        }
    }
}

extension String {
    var trimmed: String { trimmingCharacters(in: .whitespacesAndNewlines) }
}
