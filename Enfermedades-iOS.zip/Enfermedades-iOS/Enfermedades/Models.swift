import Foundation
import Observation

struct Illness: Codable, Identifiable {
    var id = UUID()
    var name = ""
    var summary = ""
    var animation: HeaderStyle = .aurora
    var gif: String?
    var artwork: Int?
    var animatedArtwork: Bool?
    var created = Date()
    var entries: [Entry] = []

    var updated: Date { max(entries.first?.created ?? created, created) }
    var illustration: Int {
        artwork ?? name.utf16.reduce(0) { ($0 + Int($1)) % 12 }
    }
    var showsAnimatedArtwork: Bool { animatedArtwork ?? (animation == .gif && gif != nil) }

    func statusBefore(_ entry: Entry) -> Entry? {
        entries.first { $0.kind == .status && $0.id != entry.id && $0.created <= entry.created }
    }

    mutating func put(_ entry: Entry) {
        entries.removeAll { $0.id == entry.id }
        entries.insert(entry, at: 0)
        entries.sort { $0.created > $1.created }
    }
}

enum HeaderStyle: String, Codable, CaseIterable, Identifiable {
    case aurora, waves, orbit, gif
    var id: String { rawValue }
    var label: String {
        switch self {
        case .aurora: "Aurora"
        case .waves: "Ondas"
        case .orbit: "Órbita"
        case .gif: "Mi GIF"
        }
    }
    var icon: String {
        switch self {
        case .aurora: "sparkles"
        case .waves: "waveform.path"
        case .orbit: "circle.hexagongrid"
        case .gif: "photo.on.rectangle"
        }
    }
}

struct Entry: Codable, Identifiable {
    var id = UUID()
    var title = ""
    var notes = ""
    var created = Date()
    var severity = 55
    var photos: [String] = []
    var health: [HealthAttachment] = []
    var recordKind: RecordKind?
    var diseaseState: DiseaseState?

    var kind: RecordKind { recordKind ?? .status }
    var displayTitle: String {
        guard title.isEmpty else { return title }
        switch kind {
        case .status: return status
        case .note: return "Nota de seguimiento"
        case .attachments: return health.isEmpty ? "Adjuntos" : health.map(\.name).joined(separator: ", ")
        }
    }

    var status: String {
        switch severity {
        case 0: "Curada"
        case 1...24: "Leve"
        case 25...59: "Moderada"
        case 60...94: "Fuerte"
        default: "Muy fuerte"
        }
    }

    func evolution(since previous: Entry?) -> EntryEvolution? {
        guard severity > 0, let previous else { return nil }
        if previous.severity == 0 { return .relapse }
        switch severity - previous.severity {
        case ..<(-14): return severity <= 24 ? .recovering : .improving
        case -14 ... -1: return .slightImprovement
        case 0: return .stable
        case 1...14: return .slightWorsening
        default: return .worsening
        }
    }
}

// Kept for journals created before all new records used the severity slider.
enum RecordKind: String, Codable {
    case status, note, attachments
}

enum DiseaseState: String, Codable {
    case active, worsening, improving, recovering, recovered
}

struct DiseaseHistory {
    struct Episode {
        let start: Date
        var end: Date?
    }

    let calendar: Calendar
    let today: Date
    let entries: [Entry]
    let start: Date
    let episodes: [Episode]
    private let states: [Entry]
    private let byDay: [Date: [Entry]]

    init(illness: Illness, calendar: Calendar = .current, now: Date = .now) {
        self.calendar = calendar
        today = calendar.startOfDay(for: now)
        let records = illness.entries.filter { $0.created <= now }
        let changes = records.filter { $0.kind == .status }
        entries = records
        states = changes
        start = calendar.startOfDay(for: min(illness.created, records.last?.created ?? illness.created))

        var periods: [Episode] = []
        var graphEntries: [Entry] = []
        for entry in changes.reversed() {
            if entry.severity == 0 {
                guard let last = periods.indices.last, periods[last].end == nil else { continue }
                periods[last].end = entry.created
            } else if periods.isEmpty || periods.last?.end != nil {
                periods.append(Episode(start: entry.created))
            }
            graphEntries.append(entry)
        }
        episodes = periods
        byDay = Dictionary(grouping: graphEntries.reversed()) { calendar.startOfDay(for: $0.created) }
    }

    func day(_ date: Date) -> Date { calendar.startOfDay(for: date) }
    func shift(_ date: Date, by days: Int) -> Date {
        calendar.date(byAdding: .day, value: days, to: date) ?? date
    }

    func entryTime(on date: Date, now: Date = .now) -> Date {
        if day(date) == day(now) { return now }
        return calendar.date(bySettingHour: calendar.component(.hour, from: now),
                             minute: calendar.component(.minute, from: now),
                             second: 0, of: day(date)) ?? date
    }

    private func status(before date: Date, including: Bool = false) -> Entry? {
        var lower = 0
        var upper = states.count
        while lower < upper {
            let mid = lower + (upper - lower) / 2
            let time = states[mid].created
            if time < date || (including && time == date) { upper = mid }
            else { lower = mid + 1 }
        }
        return lower < states.count ? states[lower] : nil
    }

    func lastSeverity(at date: Date) -> Int? { status(before: date, including: true)?.severity }

    func allowsAttachments(at date: Date) -> Bool { (lastSeverity(at: date) ?? 0) > 0 }

    func continuation(on date: Date) -> (severity: Int, days: Int)? {
        let date = day(date)
        guard date <= today, let inherited = status(before: date), inherited.severity > 0,
              let episode = episodes.last(where: { $0.start < date && ($0.end.map { $0 > date } ?? true) })
        else { return nil }

        let days = (calendar.dateComponents([.day], from: day(episode.start), to: date).day ?? 0) + 1
        return (inherited.severity, days)
    }

    func colors(on date: Date) -> [Int] {
        let date = day(date)
        guard date <= today else { return [] }
        var values = byDay[date, default: []].reversed().map(\.severity)
        if let inherited = continuation(on: date), values.first != inherited.severity {
            values.insert(inherited.severity, at: 0)
        }
        return values
    }

    func trend(on date: Date) -> EntryEvolution? {
        guard let current = byDay[day(date)]?.first else { return nil }
        let sameDay = byDay[day(date), default: []]
        let previous = sameDay.dropFirst().first ?? status(before: day(date))
        if current.severity == 0, let previous, previous.severity > 0 { return .recovering }
        return current.evolution(since: previous)
    }

    var recovered: Bool { states.first?.severity == 0 }
    var cardDay: Date { recovered ? day(latestEpisode?.end ?? states.first?.created ?? today) : today }
    var cardEntry: Entry? { states.first }
    var latestEpisode: Episode? { episodes.last }

    func attachments(in episode: Episode, kind: HealthKind) -> [String] {
        var names = Set<String>()
        return entries.filter { entry in
            entry.created >= episode.start && (episode.end.map { entry.created <= $0 } ?? true)
        }
        .flatMap(\.health)
        .filter { $0.kind == kind && names.insert($0.name.folding(options: [.caseInsensitive, .diacriticInsensitive], locale: .current)).inserted }
        .map(\.name)
    }
}

enum EntryEvolution: String {
    case recovering = "Recuperándose"
    case improving = "Mejorando"
    case slightImprovement = "Leve mejoría"
    case stable = "Sin cambios"
    case slightWorsening = "Leve empeoramiento"
    case worsening = "Empeorando"
    case relapse = "Reapareció"

    var icon: String {
        switch self {
        case .recovering, .improving, .slightImprovement: "arrow.down.right"
        case .stable: "minus"
        case .slightWorsening, .worsening: "arrow.up.right"
        case .relapse: "arrow.counterclockwise"
        }
    }
}

enum HealthKind: String, Codable, CaseIterable, Identifiable {
    case symptom, medication
    var id: String { rawValue }
    var title: String { self == .symptom ? "Síntomas" : "Medicamentos" }
    var singular: String { self == .symptom ? "Síntoma" : "Medicamento" }
    var icon: String { self == .symptom ? "waveform.path.ecg" : "pills" }
}

struct HealthAttachment: Codable, Identifiable, Equatable {
    var id: String = UUID().uuidString
    var kind: HealthKind
    var name: String
    var detail: String = ""
    var date: Date?
    var fromHealth = false
}

private struct JournalArchive: Decodable {
    let version: Int
    let illnesses: [Illness]
}

@MainActor @Observable
final class Journal {
    private(set) var illnesses: [Illness] = []
    private(set) var loadError: String?
    private let folder = URL.applicationSupportDirectory.appending(path: "Enfermedades", directoryHint: .isDirectory)
    private var records: URL { folder.appending(path: "journal.json") }

    init() {
        do {
            try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
            try FileManager.default.setAttributes([.protectionKey: FileProtectionType.complete], ofItemAtPath: folder.path)
            var privateFolder = folder
            var values = URLResourceValues()
            values.isExcludedFromBackup = true
            try privateFolder.setResourceValues(values)
            if FileManager.default.fileExists(atPath: records.path) {
                illnesses = try JSONDecoder().decode([Illness].self, from: Data(contentsOf: records))
            }
            removeUnusedMedia()
        } catch {
            loadError = error.localizedDescription
        }
    }

    func illness(_ id: UUID) -> Illness? { illnesses.first { $0.id == id } }

    func media(_ name: String) -> URL { folder.appending(path: name) }

    func save(_ illness: Illness, media staged: [String: Data] = [:]) throws {
        var updated = illnesses.filter { $0.id != illness.id }
        updated.append(illness)
        try persist(updated, media: staged)
    }

    func importArchive(from url: URL) throws -> (illnesses: Int, entries: Int) {
        let accessed = url.startAccessingSecurityScopedResource()
        defer { if accessed { url.stopAccessingSecurityScopedResource() } }
        let maxBytes = 2 * 1024 * 1024
        guard let size = try url.resourceValues(forKeys: [.fileSizeKey]).fileSize, size <= maxBytes else {
            throw CocoaError(.fileReadTooLarge)
        }
        let data = try Data(contentsOf: url)
        guard data.count <= maxBytes else { throw CocoaError(.fileReadTooLarge) }
        let archive = try JSONDecoder().decode(JournalArchive.self, from: data)
        guard archive.version == 1, !archive.illnesses.isEmpty,
              Set(archive.illnesses.map(\.id)).count == archive.illnesses.count,
              archive.illnesses.allSatisfy({ illness in
                  !illness.name.trimmed.isEmpty && illness.gif == nil
                  && Set(illness.entries.map(\.id)).count == illness.entries.count
                  && illness.entries.allSatisfy { (0...100).contains($0.severity) && $0.photos.isEmpty && $0.health.allSatisfy { !$0.fromHealth } }
              }) else {
            throw CocoaError(.fileReadCorruptFile)
        }

        var updated = illnesses
        var illnessCount = 0
        var entryCount = 0
        for var incoming in archive.illnesses {
            incoming.entries.sort { $0.created > $1.created }
            let existing = updated.firstIndex { $0.id == incoming.id }
                ?? updated.firstIndex {
                    $0.name.trimmed.compare(incoming.name.trimmed, options: [.caseInsensitive, .diacriticInsensitive]) == .orderedSame
                }
            var added = incoming.entries
            if let index = existing {
                let ids = Set(updated[index].entries.map(\.id))
                added = incoming.entries.filter { !ids.contains($0.id) }
                if !added.isEmpty {
                    updated[index].entries.append(contentsOf: added)
                    updated[index].entries.sort { $0.created > $1.created }
                    updated[index].created = min(updated[index].created, incoming.created)
                    if !incoming.summary.isEmpty, !updated[index].summary.contains(incoming.summary) {
                        let previous = updated[index].summary
                        updated[index].summary = previous.isEmpty ? incoming.summary : previous + "\n\n" + incoming.summary
                    }
                }
            } else {
                updated.append(incoming)
                illnessCount += 1
            }
            entryCount += added.count
        }
        if illnessCount > 0 || entryCount > 0 { try persist(updated, media: [:]) }
        return (illnessCount, entryCount)
    }

    private func persist(_ updated: [Illness], media staged: [String: Data]) throws {
        guard loadError == nil else { throw CocoaError(.fileReadCorruptFile) }
        let sorted = updated.sorted { $0.updated > $1.updated }
        var written: [URL] = []
        do {
            for (name, data) in staged {
                let url = media(name)
                try data.write(to: url, options: [.atomic, .completeFileProtection])
                written.append(url)
            }
            try JSONEncoder().encode(sorted).write(to: records, options: [.atomic, .completeFileProtection])
        } catch {
            for url in written { try? FileManager.default.removeItem(at: url) }
            throw error
        }
        illnesses = sorted
        removeUnusedMedia()
    }

    private func removeUnusedMedia() {
        let used = Set(illnesses.flatMap { illness in
            [illness.gif].compactMap { $0 } + illness.entries.flatMap(\.photos)
        })
        guard let files = try? FileManager.default.contentsOfDirectory(at: folder, includingPropertiesForKeys: nil) else { return }
        for url in files where ["gif", "jpg"].contains(url.pathExtension) && !used.contains(url.lastPathComponent) {
            try? FileManager.default.removeItem(at: url)
        }
    }
}

extension String {
    var trimmed: String { trimmingCharacters(in: .whitespacesAndNewlines) }
}
