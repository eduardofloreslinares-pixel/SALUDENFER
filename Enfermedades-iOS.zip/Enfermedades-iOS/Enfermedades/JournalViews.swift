import SwiftUI
import UIKit

struct HomeView: View {
    @Environment(Journal.self) private var journal
    @State private var path: [UUID] = []
    @State private var newIllness = false

    var body: some View {
        NavigationStack(path: $path) {
            ScrollView {
                VStack(alignment: .leading, spacing: 15) {
                    Text("Enfermedades")
                        .font(.largeTitle.weight(.bold))
                        .accessibilityAddTraits(.isHeader)
                        .padding(.top, 18)
                        .padding(.bottom, 5)
                    if let error = journal.loadError {
                        ContentUnavailableView("Historial no disponible", systemImage: "lock",
                                               description: Text(error))
                    } else if journal.illnesses.isEmpty {
                        VStack(alignment: .leading, spacing: 10) {
                            Text("Aún no hay enfermedades").font(.title3.bold())
                            Text("Crea una para empezar a registrar cómo evoluciona.")
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                            Button("Nueva enfermedad", systemImage: "plus") { newIllness = true }
                                .buttonStyle(.glass)
                                .padding(.top, 7)
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(23)
                        .modifier(BubbleSurface())
                    } else {
                        GlassEffectContainer(spacing: 10) {
                            VStack(spacing: 15) {
                                ForEach(journal.illnesses) { illness in
                                    Button { path.append(illness.id) } label: { IllnessCard(illness: illness) }
                                        .buttonStyle(.plain)
                                }
                            }
                        }
                    }
                }
                .frame(maxWidth: 620)
                .padding(.horizontal, 22)
                .padding(.bottom, 36)
                .frame(maxWidth: .infinity)
            }
            .background(Color(uiColor: .systemBackground).ignoresSafeArea())
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    if !journal.illnesses.isEmpty {
                        Button("Nueva enfermedad", systemImage: "plus") { newIllness = true }
                            .labelStyle(.iconOnly)
                    }
                }
            }
            .navigationDestination(for: UUID.self) { id in
                if let illness = journal.illness(id) { IllnessDetail(illness: illness) }
            }
            .sheet(isPresented: $newIllness) {
                IllnessForm(illness: Illness(), creating: true) { id in path.append(id) }
            }
        }
    }
}

private struct IllnessCard: View {
    let illness: Illness
    private var cured: Bool { illness.latest?.severity == 0 }
    private var tint: Color? {
        guard let entry = illness.latest, !cured else { return nil }
        return Palette.severity(entry.severity)
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 9) {
            HStack(spacing: 7) {
                if let entry = illness.latest {
                    EntryStatus(entry: entry, previous: illness.previous)
                } else {
                    Text("Sin registros")
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(.secondary)
                }
                Spacer()
                Image(systemName: "chevron.right")
                    .font(.caption.bold())
                    .foregroundStyle(.secondary)
            }
            Text(illness.name)
                .font(.title2.weight(.bold))
            if let entry = illness.latest {
                Text(entry.title)
                    .font(.subheadline.weight(.medium))
                    .foregroundStyle(.secondary)
                    .lineLimit(2)
            } else if !illness.summary.isEmpty {
                Text(illness.summary).font(.subheadline).foregroundStyle(.secondary).lineLimit(2)
            }
            if cured {
                if let date = illness.lastActive?.created {
                    Text("Última vez · \(date.formatted(.dateTime.day().month(.abbreviated).year().locale(Locale(identifier: "es_PE"))))")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                } else if let date = illness.latest?.created {
                    Text("Curada el \(date.formatted(.dateTime.day().month(.abbreviated).year().locale(Locale(identifier: "es_PE"))))")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
        }
        .padding(21)
        .frame(maxWidth: .infinity, alignment: .leading)
        .modifier(BubbleSurface(tint: tint, interactive: true))
        .contentShape(.rect(cornerRadius: 31))
    }
}

private struct IllnessDetail: View {
    let illness: Illness
    @Environment(Journal.self) private var journal
    @State private var editingIllness = false
    @State private var editingEntry: Entry?

    var body: some View {
        ScrollView {
            VStack(spacing: 0) {
                header
                if illness.entries.isEmpty {
                    ContentUnavailableView("Sin registros", systemImage: "bubble.left",
                                           description: Text("Toca + para añadir la primera entrada."))
                        .padding(.vertical, 16)
                } else {
                    HistoryTimeline(entries: illness.entries) { entry in
                        editingEntry = entry
                    }
                }
            }
            .frame(maxWidth: 620)
            .frame(maxWidth: .infinity)
            .padding(.bottom, 20)
        }
        .background(Color(uiColor: .systemBackground).ignoresSafeArea())
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button("Editar enfermedad", systemImage: "ellipsis") { editingIllness = true }
                    .labelStyle(.iconOnly)
            }
        }
        .safeAreaInset(edge: .bottom, spacing: 0) {
            Button {
                var entry = Entry()
                if let severity = illness.latest?.severity, severity > 0 { entry.severity = severity }
                editingEntry = entry
            } label: {
                Image(systemName: "plus")
                    .font(.title2.weight(.semibold))
                    .foregroundStyle(.primary)
                    .frame(width: 46, height: 46)
            }
            .buttonStyle(.glass)
            .buttonBorderShape(.circle)
            .accessibilityLabel("Añadir registro")
            .padding(.vertical, 11)
            .frame(maxWidth: .infinity)
        }
        .sheet(isPresented: $editingIllness) {
            IllnessForm(illness: illness, creating: false) { _ in }
        }
        .sheet(item: $editingEntry) { entry in
            EntryForm(illnessID: illness.id, entry: entry)
        }
    }

    private var header: some View {
        VStack(spacing: 12) {
            if let latest = illness.latest {
                EntryStatus(entry: latest, previous: illness.previous)
                    .padding(.horizontal, 13)
                    .padding(.vertical, 8)
                    .glassEffect(.regular, in: .rect(cornerRadius: 19))
            }
            Text(illness.name)
                .font(.largeTitle.weight(.bold))
                .multilineTextAlignment(.center)
                .accessibilityAddTraits(.isHeader)
            if !illness.summary.isEmpty {
                Text(illness.summary)
                    .font(.subheadline)
                    .multilineTextAlignment(.center)
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
        .padding(.horizontal, 26)
        .padding(.vertical, 40)
        .frame(maxWidth: .infinity, minHeight: 235)
        .background {
            HeaderArtwork(style: illness.animation, gifURL: illness.gif.map { journal.media($0) }, reloadID: illness.gif)
                .clipShape(.rect)
        }
    }
}

private struct HistoryTimeline: View {
    let entries: [Entry]
    let onSelect: (Entry) -> Void

    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var source: (id: UUID, bottom: CGFloat)?

    init(entries: [Entry], onSelect: @escaping (Entry) -> Void) {
        self.entries = entries
        self.onSelect = onSelect
    }

    var body: some View {
        let previousEntries = Dictionary(uniqueKeysWithValues: zip(entries.map(\.id), entries.dropFirst()))
        let latest = entries.first

        VStack(spacing: 0) {
            VStack(spacing: 18) {
                ForEach(entries) { entry in
                    let isLatest = entry.id == latest?.id
                    Button { onSelect(entry) } label: {
                        if isLatest && !reduceMotion {
                            TimelineView(.animation(minimumInterval: 1.0 / 30)) { timeline in
                                let wave = HistoryWave(severity: entry.severity,
                                                       time: timeline.date.timeIntervalSinceReferenceDate)
                                EntryBubble(entry: entry, previous: previousEntries[entry.id], outline: wave.outline)
                            }
                        } else {
                            EntryBubble(entry: entry, previous: previousEntries[entry.id],
                                        outline: HistoryOutline())
                        }
                    }
                    .buttonStyle(.plain)
                    .accessibilityHint("Abre el registro para verlo o editarlo")
                    .onGeometryChange(for: CGFloat.self) { geometry in
                        isLatest ? geometry.frame(in: .named("historyWaveField")).maxY : 0
                    } action: { bottom in
                        if isLatest { source = (entry.id, bottom) }
                    }
                    .modifier(HistoryPerspective(enabled: !isLatest && !reduceMotion))
                }
            }
            .padding(.horizontal, 28)
            .padding(.top, 6)
            .padding(.bottom, entries.count == 1 && !reduceMotion ? 70 : 24)
            .coordinateSpace(name: "historyWaveField")
            .background {
                if !reduceMotion, let latest, let source, source.id == latest.id {
                    TimelineView(.animation(minimumInterval: 1.0 / 30)) { timeline in
                        let wave = HistoryWave(severity: latest.severity,
                                               time: timeline.date.timeIntervalSinceReferenceDate)
                        HistoryWaveField(wave: wave, origin: source.bottom)
                    }
                }
            }

            if !reduceMotion && entries.count > 1 {
                // Give the oldest entry room to scroll into the readable foreground.
                Color.clear
                    .containerRelativeFrame(.vertical) { length, _ in length * 0.54 }
                    .allowsHitTesting(false)
                    .accessibilityHidden(true)
            }
        }
    }
}

private struct HistoryPerspective: ViewModifier {
    let enabled: Bool

    func body(content: Content) -> some View {
        content.visualEffect { effect, geometry in
            let viewport = geometry.bounds(of: .scrollView(axis: .vertical))?.height ?? 0
            let top = geometry.frame(in: .scrollView(axis: .vertical)).minY
            let position = viewport > 0 && enabled ? top / viewport : 0
            let fraction = min(max((position - 0.34) / 0.61, 0), 1)
            let depth = fraction * fraction * (3 - 2 * fraction)

            return effect
                .rotation3DEffect(.degrees(-27 * Double(depth)),
                                  axis: (x: 1, y: 0, z: 0), anchor: .top, perspective: 0.65)
                .scaleEffect(x: 1 - 0.25 * depth, y: 1 - 0.12 * depth, anchor: .top)
                .offset(y: -24 * depth)
                .opacity(1 - 0.65 * Double(depth))
        }
    }
}

private struct EntryBubble: View {
    let entry: Entry
    let previous: Entry?
    let outline: HistoryOutline
    @Environment(Journal.self) private var journal

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            EntryStatus(entry: entry, previous: previous)
            VStack(alignment: .leading, spacing: 5) {
                Text(entry.title).font(.title3.weight(.bold))
                if !entry.notes.isEmpty {
                    Text(entry.notes)
                        .font(.body)
                        .foregroundStyle(.primary.opacity(0.85))
                }
            }
            if !entry.photos.isEmpty {
                PhotoStrip(names: entry.photos, url: { journal.media($0) })
            }
            if !entry.health.isEmpty {
                VStack(alignment: .leading, spacing: 7) {
                    ForEach(entry.health) { item in HealthAttachmentLabel(item: item) }
                }
            }
            ViewThatFits(in: .horizontal) {
                HStack { date; Spacer(minLength: 9); time }
                VStack(alignment: .leading, spacing: 4) { date; time }
            }
            .font(.caption.weight(.medium))
            .foregroundStyle(.secondary)
            .padding(.top, 2)
        }
        .padding(21)
        .frame(maxWidth: .infinity, alignment: .leading)
        .modifier(BubbleSurface(tint: Palette.severity(entry.severity), interactive: true, outline: outline))
        .contentShape(.rect(cornerRadius: 31))
    }

    private var date: some View {
        Label {
            Text(entry.created, format: .dateTime.day().month(.abbreviated).year())
        } icon: { Image(systemName: "calendar") }
    }

    private var time: some View {
        Label {
            Text(entry.created, format: .dateTime.hour().minute())
        } icon: { Image(systemName: "clock") }
    }
}

struct PhotoStrip: View {
    let names: [String]
    let url: (String) -> URL
    var drafts: [String: Data] = [:]
    var remove: ((String) -> Void)?
    var open: ((String) -> Void)?

    var body: some View {
        ScrollView(.horizontal) {
            HStack(spacing: 8) {
                ForEach(names, id: \.self) { name in
                    let thumbnail = PhotoThumbnail(name: name, url: url(name), bytes: drafts[name])
                    Group {
                        if let open {
                            Button { open(name) } label: { thumbnail }
                                .buttonStyle(.plain)
                                .accessibilityLabel("Ver foto")
                        } else {
                            thumbnail
                        }
                    }
                    .overlay(alignment: .topTrailing) {
                        if let remove {
                            Button { remove(name) } label: {
                                Image(systemName: "xmark.circle.fill")
                                    .symbolRenderingMode(.palette)
                                    .foregroundStyle(.white, .black.opacity(0.78))
                                    .padding(7)
                            }
                            .buttonStyle(.plain)
                            .accessibilityLabel("Quitar foto")
                        }
                    }
                }
            }
        }
        .scrollIndicators(.hidden)
    }
}

private struct PhotoThumbnail: View {
    let name: String
    let url: URL
    let bytes: Data?
    @State private var image: UIImage?

    var body: some View {
        Group {
            if let image {
                Image(uiImage: image).resizable().scaledToFill()
            } else {
                Rectangle().fill(.primary.opacity(0.08))
                    .overlay(Image(systemName: "photo").foregroundStyle(.secondary))
            }
        }
        .frame(width: 92, height: 74)
        .clipShape(.rect(cornerRadius: 13))
        .accessibilityHidden(true)
        .task(id: name) {
            image = await Task.detached(priority: .utility) {
                PhotoDecoder.thumbnail(bytes: bytes, url: url, size: 220)
            }.value
        }
    }
}
