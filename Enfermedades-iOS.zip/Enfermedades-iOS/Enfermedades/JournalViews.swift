import SwiftUI
import UIKit

struct HomeView: View {
    @Environment(Journal.self) private var journal
    @State private var path: [UUID] = []
    @State private var creating = false

    var body: some View {
        NavigationStack(path: $path) {
            ScrollView {
                VStack(alignment: .leading, spacing: 10) {
                    HStack {
                        Text(journal.illnesses.isEmpty ? "Ningún dato disponible" : "Registradas")
                            .font(.headline)
                            .accessibilityAddTraits(.isHeader)
                        Spacer()
                        Button { creating = true } label: {
                            Image(systemName: "plus")
                                .font(.title3.weight(.semibold))
                                .frame(width: 44, height: 44)
                        }
                        .buttonStyle(.glass)
                        .buttonBorderShape(.circle)
                        .accessibilityLabel("Añadir enfermedad")
                        .disabled(journal.loadError != nil)
                    }
                    .padding(.horizontal, 4)

                    if journal.loadError != nil {
                        ContentUnavailableView("Historial no disponible", systemImage: "lock",
                                               description: Text("No se pudieron abrir los registros guardados."))
                    }
                    ForEach(journal.illnesses) { illness in
                        NavigationLink(value: illness.id) { DiseaseCard(illness: illness) }
                            .buttonStyle(.plain)
                    }
                }
                .padding(.horizontal, 16)
                .padding(.bottom, 24)
                .frame(maxWidth: 620)
                .frame(maxWidth: .infinity)
            }
            .background(DiseaseColors.grouped)
            .navigationTitle("Enfermedades")
            .navigationBarTitleDisplayMode(.large)
            .navigationDestination(for: UUID.self) { id in
                if let illness = journal.illness(id) {
                    IllnessDetail(illness: illness)
                        .id(id)
                } else {
                    ContentUnavailableView("Enfermedad no disponible", systemImage: "tray")
                }
            }
            .sheet(isPresented: $creating) {
                IllnessForm(illness: Illness(), creating: true) { id in path.append(id) }
            }
        }
    }
}

private struct DiseaseCard: View {
    let illness: Illness
    var highlighted = false

    var body: some View {
        let history = DiseaseHistory(illness: illness)
        let day = history.cardDay
        let records = history.records(day)
        let state = history.status(on: day)?.state ?? .active

        VStack(alignment: .leading, spacing: highlighted ? 17 : 20) {
            HStack {
                Label(state.label, systemImage: state.icon)
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(state.ink)
                Spacer()
                if !highlighted {
                    if let date = records.first?.created {
                        Text(date, format: .dateTime.hour().minute())
                            .font(.caption)
                    }
                    Image(systemName: "chevron.right")
                        .font(.caption2.weight(.semibold))
                        .accessibilityHidden(true)
                }
            }
            .foregroundStyle(.secondary)
            HStack(alignment: .bottom) {
                VStack(alignment: .leading, spacing: 5) {
                    Text(illness.name)
                        .font(highlighted ? .title3.bold() : .headline)
                        .foregroundStyle(highlighted ? Color.primary : DiseaseColors.name)
                    if highlighted {
                        Text(highlightSummary(history))
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    } else if day == history.today {
                        Text("Hoy").font(.caption).foregroundStyle(.secondary)
                    } else {
                        Text(day, format: .dateTime.day().month(.abbreviated).year())
                            .font(.caption).foregroundStyle(.secondary)
                    }
                }
                Spacer(minLength: 12)
                DayCapsule(state: history.marker(on: day), entries: records, compact: true)
                    .accessibilityHidden(true)
            }
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(DiseaseColors.surface, in: .rect(cornerRadius: 13))
        .overlay {
            RoundedRectangle(cornerRadius: 13)
                .strokeBorder(Color.primary.opacity(0.07), lineWidth: 0.5)
        }
        .accessibilityElement(children: .combine)
    }

    private func highlightSummary(_ history: DiseaseHistory) -> String {
        let attachments = illness.entries.flatMap(\.health)
        let symptoms = Set(attachments.filter { $0.kind == .symptom }.map(\.name)).count
        let meds = Set(attachments.filter { $0.kind == .medication }.map(\.name)).count
        let days = history.daysTracked
        return "\(days) \(days == 1 ? "día" : "días") de seguimiento · \(symptoms) \(symptoms == 1 ? "síntoma" : "síntomas") · \(meds) \(meds == 1 ? "medicamento" : "medicamentos")"
    }
}

private enum DayCategory: String, Identifiable {
    case notes, symptoms, medications
    var id: Self { self }
    var title: String {
        switch self {
        case .notes: "Notas del día"
        case .symptoms: "Síntomas del día"
        case .medications: "Medicamentos del día"
        }
    }
    var healthKind: HealthKind? {
        switch self {
        case .notes: nil
        case .symptoms: .symptom
        case .medications: .medication
        }
    }
    func matches(_ entry: Entry) -> Bool {
        if let healthKind { return entry.health.contains { $0.kind == healthKind } }
        return entry.hasNotes
    }
}

private enum DetailSheet: Identifiable {
    case entry(Entry)
    case day(DayCategory, Date)
    case about, artwork, calendar

    var id: String {
        switch self {
        case .entry(let entry): entry.id.uuidString
        case .day(let category, let date): "\(category.rawValue)-\(date.timeIntervalSinceReferenceDate)"
        case .about: "about"
        case .artwork: "artwork"
        case .calendar: "calendar"
        }
    }
}

private struct IllnessDetail: View {
    let illness: Illness
    @State private var selectedDay = Calendar.current.startOfDay(for: .now)
    @State private var dayCenter = Calendar.current.startOfDay(for: .now)
    @State private var sheet: DetailSheet?
    @State private var filter: HistoryFilter = .timeline
    @State private var expanded = false

    var body: some View {
        let history = DiseaseHistory(illness: illness)
        ScrollView {
            VStack(spacing: 0) {
                DiseaseCalendar(history: history, selected: $selectedDay, center: $dayCenter) {
                    sheet = .calendar
                }
                Divider()
                dayLog(history)
                VStack(alignment: .leading, spacing: 13) {
                    heading("Lo destacado", action: "Información") { sheet = .about }
                    DiseaseCard(illness: illness, highlighted: true)
                    historySection(history)
                    heading("Acerca de la enfermedad", action: "Editar") { sheet = .about }
                        .padding(.top, 12)
                    about
                }
                .padding(16)
                .padding(.bottom, 12)
            }
            .frame(maxWidth: 620)
            .frame(maxWidth: .infinity)
        }
        .background(DiseaseColors.grouped)
        .navigationTitle(illness.name)
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Menu {
                    Button("Estado de la enfermedad", systemImage: "circle.lefthalf.filled") {
                        openStatus(history, adding: true)
                    }
                    .disabled(selectedDay > history.today)
                    Button("Nota de seguimiento", systemImage: "note.text") {
                        sheet = .day(.notes, selectedDay)
                    }
                    Button("Síntomas", systemImage: HealthKind.symptom.icon) {
                        sheet = .day(.symptoms, selectedDay)
                    }
                    Button("Medicamentos", systemImage: HealthKind.medication.icon) {
                        sheet = .day(.medications, selectedDay)
                    }
                } label: {
                    Label("Agregar", systemImage: "plus")
                }
            }
        }
        .sheet(item: $sheet) { item in
            switch item {
            case .entry(let entry):
                EntryForm(illnessID: illness.id, entry: entry)
            case .day(let category, let date):
                DayRecords(illnessID: illness.id, day: date, category: category)
            case .about:
                IllnessForm(illness: illness, creating: false) { _ in }
            case .artwork:
                IllustrationPicker(illnessID: illness.id)
            case .calendar:
                NavigationStack {
                    DatePicker("Elegir día", selection: Binding(
                        get: { selectedDay },
                        set: { select($0, history: history) }
                    ), displayedComponents: .date)
                    .datePickerStyle(.graphical)
                    .padding(.horizontal)
                    .navigationTitle("Elegir día")
                    .navigationBarTitleDisplayMode(.inline)
                    .toolbar {
                        ToolbarItem(placement: .confirmationAction) {
                            Button("Listo", systemImage: "checkmark") { sheet = nil }
                        }
                    }
                }
                .presentationDetents([.medium, .large])
            }
        }
    }

    private func select(_ date: Date, history: DiseaseHistory) {
        selectedDay = history.day(date)
        dayCenter = selectedDay
    }

    private func openStatus(_ history: DiseaseHistory, adding: Bool = false) {
        if !adding, let existing = history.records(selectedDay).first(where: { $0.kind == .status }) {
            sheet = .entry(existing)
        } else if selectedDay <= history.today {
            let date = history.entryTime(on: selectedDay)
            let state = history.status(on: selectedDay)?.state ?? .active
            let severity = history.entries.first { $0.kind == .status && $0.created <= date }?.severity ?? 55
            sheet = .entry(Entry(created: date, severity: severity > 0 ? severity : 55,
                                 diseaseState: state == .recovered ? .active : state))
        }
    }

    private func dayLog(_ history: DiseaseHistory) -> some View {
        let records = history.records(selectedDay)
        let symptoms = records.flatMap(\.health).filter { $0.kind == .symptom }
        let medications = records.flatMap(\.health).filter { $0.kind == .medication }
        let notes = records.filter(\.hasNotes).count
        let state = history.status(on: selectedDay)?.state

        return VStack(alignment: .leading, spacing: 9) {
            heading("Registro del día", action: "Hoy") { select(history.today, history: history) }
            rowLabel("ESTADO", tint: DiseaseColors.coral)
            logRow("Enfermedad", value: state?.label ?? "Sin registro",
                   tint: DiseaseColors.coral, valueTint: state?.ink) { openStatus(history) }
                .disabled(selectedDay > history.today)

            rowLabel("OTROS DATOS", tint: DiseaseColors.violet).padding(.top, 7)
            VStack(spacing: 0) {
                logRow("Síntomas", value: symptoms.isEmpty ? "Sin registros" : symptoms.map(\.name).joined(separator: ", "),
                       tint: DiseaseColors.violet, rounded: false) { sheet = .day(.symptoms, selectedDay) }
                Rectangle().fill(DiseaseColors.violet.opacity(0.12)).frame(height: 0.5)
                logRow("Notas", value: notes == 0 ? "Agregar" : String(notes),
                       tint: DiseaseColors.violet, rounded: false) { sheet = .day(.notes, selectedDay) }
            }
            .clipShape(.rect(cornerRadius: 10))

            rowLabel("TRATAMIENTO", tint: DiseaseColors.teal).padding(.top, 7)
            logRow("Medicamentos", value: medications.isEmpty ? "Sin vincular" : "\(medications.count) \(medications.count == 1 ? "registro" : "registros")",
                   tint: DiseaseColors.teal) { sheet = .day(.medications, selectedDay) }
        }
        .padding(.horizontal, 16)
        .padding(.top, 15)
        .padding(.bottom, 24)
        .background(DiseaseColors.surface)
    }

    private func rowLabel(_ title: String, tint: Color) -> some View {
        HStack(spacing: 4) {
            Circle().fill(tint).frame(width: 4, height: 4)
            Text(title).font(.caption2.weight(.semibold)).foregroundStyle(tint)
        }
        .accessibilityAddTraits(.isHeader)
    }

    private func logRow(_ title: String, value: String, tint: Color, valueTint: Color? = nil,
                        rounded: Bool = true, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(spacing: 8) {
                Text(title).font(.subheadline).foregroundStyle(.primary)
                Spacer(minLength: 4)
                Text(value)
                    .font(.subheadline)
                    .foregroundStyle(valueTint ?? tint)
                    .multilineTextAlignment(.trailing)
                    .lineLimit(2)
                Image(systemName: "chevron.right")
                    .font(.caption2.weight(.semibold))
                    .foregroundStyle(tint.opacity(0.65))
                    .accessibilityHidden(true)
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 9)
            .frame(minHeight: 47)
            .background(tint.opacity(0.10), in: .rect(cornerRadius: rounded ? 10 : 0))
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }

    private func historySection(_ history: DiseaseHistory) -> some View {
        let rows = filter.rows(history, limit: expanded ? nil : 7)
        return VStack(alignment: .leading, spacing: 12) {
            Picker("Registros vinculados", selection: $filter) {
                ForEach(HistoryFilter.allCases) { Text($0.label).tag($0) }
            }
            .pickerStyle(.segmented)
            .padding(.vertical, 5)
            .onChange(of: filter) { expanded = false }

            Text(filter.heading).font(.title3.bold()).accessibilityAddTraits(.isHeader)
            if rows.isEmpty {
                Text(filter.empty).font(.subheadline).foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity, alignment: .leading).padding(16)
                    .background(DiseaseColors.surface, in: .rect(cornerRadius: 13))
            } else {
                LazyVStack(spacing: 0) {
                    ForEach(expanded ? rows : Array(rows.prefix(6))) { row in
                        if let entry = row.entry {
                            Button { sheet = .entry(entry) } label: {
                                HistoryLine(row: row)
                            }
                            .buttonStyle(.plain)
                        } else {
                            HistoryLine(row: row)
                        }
                    }
                }
                .background(DiseaseColors.surface, in: .rect(cornerRadius: 13))
                if rows.count > 6 {
                    Button(expanded ? "Mostrar menos" : "Mostrar todos los datos") { expanded.toggle() }
                        .font(.subheadline.weight(.medium))
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 5)
                }
            }
        }
    }

    private var about: some View {
        VStack(alignment: .leading, spacing: 0) {
            Button { sheet = .artwork } label: {
                IllnessIllustration(illness: illness)
                    .overlay(alignment: .bottomTrailing) {
                        Image(systemName: "photo.badge.plus")
                            .font(.subheadline.weight(.semibold))
                            .padding(10)
                            .glassEffect(.regular, in: .circle)
                            .padding(9)
                    }
            }
            .buttonStyle(.plain)
            .accessibilityLabel("Cambiar ilustración")

            VStack(alignment: .leading, spacing: 8) {
                Text(illness.name).font(.headline)
                Text(illness.summary.isEmpty ? "Agrega información y notas personales sobre esta enfermedad." : illness.summary)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .textSelection(.enabled)
            }
            .padding(16)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(DiseaseColors.surface, in: .rect(cornerRadius: 14))
        .clipShape(.rect(cornerRadius: 14))
    }

    private func heading(_ title: String, action: String, perform: @escaping () -> Void) -> some View {
        HStack(alignment: .firstTextBaseline) {
            Text(title).font(.title2.bold()).accessibilityAddTraits(.isHeader)
            Spacer()
            Button(action, action: perform).font(.subheadline)
        }
    }
}
struct PhotoStrip: View {
    let names: [String]
    let url: (String) -> URL
    var drafts: [String: Data] = [:]
    var remove: ((String) -> Void)?
    var open: ((String) -> Void)?

    var body: some View {
        ScrollView(.horizontal) {
            HStack(spacing: 8) {
                ForEach(names, id: \.self) { name in
                    let thumbnail = PhotoThumbnail(name: name, url: url(name), bytes: drafts[name])
                    Group {
                        if let open {
                            Button { open(name) } label: { thumbnail }
                                .buttonStyle(.plain)
                                .accessibilityLabel("Ver foto")
                        } else {
                            thumbnail
                        }
                    }
                    .overlay(alignment: .topTrailing) {
                        if let remove {
                            Button { remove(name) } label: {
                                Image(systemName: "xmark.circle.fill")
                                    .symbolRenderingMode(.palette)
                                    .foregroundStyle(.white, .black.opacity(0.78))
                                    .padding(7)
                            }
                            .buttonStyle(.plain)
                            .accessibilityLabel("Quitar foto")
                        }
                    }
                }
            }
        }
        .scrollIndicators(.hidden)
    }
}

private struct PhotoThumbnail: View {
    let name: String
    let url: URL
    let bytes: Data?
    @State private var image: UIImage?

    var body: some View {
        Group {
            if let image {
                Image(uiImage: image).resizable().scaledToFill()
            } else {
                Rectangle().fill(.primary.opacity(0.08))
                    .overlay(Image(systemName: "photo").foregroundStyle(.secondary))
            }
        }
        .frame(width: 92, height: 74)
        .clipShape(.rect(cornerRadius: 13))
        .accessibilityHidden(true)
        .task(id: name) {
            image = await Task.detached(priority: .utility) {
                PhotoDecoder.thumbnail(bytes: bytes, url: url, size: 220)
            }.value
        }
    }
}

private struct DiseaseCalendar: View {
    let history: DiseaseHistory
    @Binding var selected: Date
    @Binding var center: Date
    let openPicker: () -> Void

    var body: some View {
        VStack(spacing: 9) {
            HStack(spacing: 7) {
                dayArrow("Día anterior", symbol: "chevron.left", offset: -1)
                Button(action: openPicker) {
                    HStack(spacing: 5) {
                        Text(heading)
                            .font(.title3.weight(.semibold))
                            .foregroundStyle(.primary)
                        Image(systemName: "chevron.down")
                            .font(.caption.weight(.semibold))
                            .foregroundStyle(.secondary)
                    }
                    .frame(minHeight: 44)
                }
                .buttonStyle(.plain)
                .accessibilityHint("Elegir otra fecha")
                dayArrow("Día siguiente", symbol: "chevron.right", offset: 1)
            }
            .padding(.horizontal, 8)

            ScrollViewReader { scroll in
                GeometryReader { geometry in
                    ScrollView(.horizontal) {
                        LazyHStack(spacing: 6) {
                            ForEach(-30...30, id: \.self) { offset in
                                let date = history.shift(center, by: offset)
                                dayButton(date) {
                                    selected = date
                                    if abs(offset) > 24 { center = date }
                                }
                                .id(date)
                            }
                        }
                        .padding(.horizontal, max(16, (geometry.size.width - 46) / 2))
                    }
                    .scrollIndicators(.hidden)
                    .defaultScrollAnchor(.center, for: .initialOffset)
                    .onChange(of: selected) {
                        if abs(history.calendar.dateComponents([.day], from: center, to: selected).day ?? 0) <= 30 {
                            withAnimation(.easeInOut(duration: 0.23)) { scroll.scrollTo(selected, anchor: .center) }
                        }
                    }
                    .onChange(of: center) {
                        scroll.scrollTo(selected, anchor: .center)
                    }
                }
                .frame(height: 125)
            }
            legend
        }
        .padding(.top, 7)
        .padding(.bottom, 15)
        .background(DiseaseColors.surface)
    }

    private var heading: String {
        let format = Date.FormatStyle(locale: Locale(identifier: "es_PE"))
            .day().month(.wide)
        if !history.calendar.isDate(selected, equalTo: history.today, toGranularity: .year) {
            return selected.formatted(format.year())
        }
        let label = selected.formatted(format)
        return selected == history.today ? "Hoy, \(label)" : label
    }

    private func dayArrow(_ label: String, symbol: String, offset: Int) -> some View {
        Button {
            let date = history.shift(selected, by: offset)
            selected = date
            let distance = history.calendar.dateComponents([.day], from: center, to: date).day ?? 0
            if abs(distance) > 24 { center = date }
        } label: {
            Image(systemName: symbol)
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(.secondary)
                .frame(width: 40, height: 44)
                .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .accessibilityLabel(label)
    }

    private func dayButton(_ date: Date, action: @escaping () -> Void) -> some View {
        let chosen = date == selected
        let state = history.marker(on: date)
        let weekday = history.calendar.component(.weekday, from: date) - 1
        return Button(action: action) {
            VStack(spacing: 5) {
                Image(systemName: "triangle.fill")
                    .rotationEffect(.degrees(180))
                    .font(.system(size: 7))
                    .opacity(chosen ? 1 : 0)
                Text(["D", "L", "M", "M", "J", "V", "S"][weekday])
                    .font(.caption2.weight(.medium))
                    .foregroundStyle(chosen ? DiseaseColors.surface : Color.secondary)
                    .frame(width: 20, height: 20)
                    .background(chosen ? Color.primary : .clear, in: .circle)
                DayCapsule(state: state, entries: history.records(date), selected: chosen)
                Text(date, format: .dateTime.day())
                    .font(.caption2.weight(date == history.today ? .bold : .regular))
                    .foregroundStyle(date == history.today || chosen ? .primary : .secondary)
            }
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .accessibilityLabel(Text(date, format: .dateTime.weekday(.wide).day().month(.wide).year()))
        .accessibilityValue(state?.label ?? "Sin registro")
        .accessibilityAddTraits(chosen ? .isSelected : [])
    }

    private var legend: some View {
        ViewThatFits(in: .horizontal) {
            HStack(spacing: 8) {
                statesLegend
                markersLegend
            }
            VStack(spacing: 6) {
                HStack(spacing: 8) { statesLegend }
                HStack(spacing: 12) { markersLegend }
            }
            ScrollView(.horizontal) {
                HStack(spacing: 8) {
                    statesLegend
                    markersLegend
                }.padding(.horizontal, 12)
            }
            .scrollIndicators(.hidden)
        }
        .foregroundStyle(.secondary)
        .padding(.top, 5)
    }

    private var statesLegend: some View {
        ForEach(DiseaseState.allCases) { state in
            HStack(spacing: 3) {
                StateOrb(state: state, size: 7)
                Text(state.label).font(.caption2.weight(.medium))
                    .fixedSize()
            }
        }
    }

    private var markersLegend: some View {
        Group {
            legendMarker("Síntomas", tint: DiseaseColors.violet)
            legendMarker("Medicación", tint: DiseaseColors.teal)
        }
    }

    private func legendMarker(_ label: String, tint: Color) -> some View {
        HStack(spacing: 3) {
            Circle().fill(tint).frame(width: 6, height: 6)
            Text(label).font(.caption2).fixedSize()
        }
    }
}

private struct DayCapsule: View {
    let state: DiseaseState?
    let entries: [Entry]
    var compact = false
    var selected = false

    var body: some View {
        VStack(spacing: compact ? 4 : 7) {
            StateOrb(state: state, size: compact ? 29 : 34)
                .scaleEffect(selected ? 1.08 : 1)
            HStack(spacing: 3) {
                if entries.contains(where: { $0.health.contains { $0.kind == .symptom } }) {
                    marker(DiseaseColors.violet)
                }
                if entries.contains(where: { $0.health.contains { $0.kind == .medication } }) {
                    marker(DiseaseColors.teal)
                }
                if entries.contains(where: \.hasNotes) { marker(.secondary) }
            }
            .frame(height: 8)
            Spacer(minLength: 0)
        }
        .padding(.top, 6)
        .frame(width: compact ? 40 : 46, height: compact ? 60 : 75)
        .background(selected ? Color(uiColor: .tertiarySystemFill) : DiseaseColors.grouped, in: .capsule)
        .accessibilityHidden(true)
    }

    private func marker(_ tint: Color) -> some View {
        Circle().fill(tint).frame(width: compact ? 6 : 7, height: compact ? 6 : 7)
    }
}

private struct DayRecords: View {
    let illnessID: UUID
    let day: Date
    let category: DayCategory
    @Environment(Journal.self) private var journal
    @Environment(\.dismiss) private var dismiss
    @State private var form: Entry?

    var body: some View {
        NavigationStack {
            if let illness = journal.illness(illnessID) {
                let history = DiseaseHistory(illness: illness)
                let records = history.records(day).filter(category.matches)
                let date = category.healthKind == nil ? history.entryTime(on: day) : history.attachmentTime(on: day)
                let canAdd = day <= history.today && date != nil
                List {
                    Section {
                        if records.isEmpty {
                            Text("Todavía no hay registros para este día.")
                                .foregroundStyle(.secondary)
                        }
                        ForEach(records) { entry in
                            Button {
                                form = entry
                            } label: {
                                VStack(alignment: .leading, spacing: 5) {
                                    Text(entry.created, format: .dateTime.hour().minute())
                                        .font(.caption).foregroundStyle(.secondary)
                                    if let kind = category.healthKind {
                                        ForEach(entry.health.filter { $0.kind == kind }) { item in
                                            HealthAttachmentLabel(item: item)
                                        }
                                    } else {
                                        Text(entry.displayTitle).font(.headline)
                                        if !entry.notes.isEmpty { Text(entry.notes).foregroundStyle(.secondary) }
                                    }
                                }
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .contentShape(Rectangle())
                            }
                            .buttonStyle(.plain)
                        }
                    } header: {
                        Text(day, format: .dateTime.day().month(.wide).year())
                    } footer: {
                        if !canAdd && category.healthKind != nil && day <= history.today {
                            Text("Los síntomas y medicamentos se añaden durante el período en curso.")
                        }
                    }
                }
                .navigationTitle(category.title)
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) { Button("Cerrar") { dismiss() } }
                    ToolbarItem(placement: .topBarTrailing) {
                        Button("Agregar", systemImage: "plus") {
                            guard let date else { return }
                            form = Entry(created: date, recordKind: category.healthKind == nil ? .note : .attachments)
                        }
                        .disabled(!canAdd)
                    }
                }
                .sheet(item: $form) { entry in
                    EntryForm(illnessID: illnessID, entry: entry,
                              suggestedHealth: entry.kind == .attachments && entry.health.isEmpty ? category.healthKind : nil)
                }
            }
        }
    }
}

private enum HistoryFilter: String, CaseIterable, Identifiable {
    case timeline, symptoms, medications

    var id: Self { self }
    var label: String {
        switch self {
        case .timeline: "Línea temporal"
        case .symptoms: "Síntomas"
        case .medications: "Medicamentos"
        }
    }
    var heading: String {
        switch self {
        case .timeline: "Evolución"
        case .symptoms: "Síntomas vinculados"
        case .medications: "Medicamentos vinculados"
        }
    }
    var empty: String {
        switch self {
        case .timeline: "Todavía no hay registros de seguimiento."
        case .symptoms: "Todavía no hay síntomas vinculados."
        case .medications: "Todavía no hay medicamentos vinculados."
        }
    }

    func rows(_ history: DiseaseHistory, limit: Int?) -> [HistoryRow] {
        switch self {
        case .timeline:
            let recorded = history.entries.lazy.flatMap { entry in
                let state = entry.kind == .status ? history.state(for: entry) : nil
                let attachments = healthRows(for: entry)
                if entry.kind == .attachments && !entry.hasNotes { return attachments }
                let title = entry.title.isEmpty ? (state?.label ?? entry.displayTitle) : entry.title
                let row = HistoryRow(id: entry.id.uuidString, date: entry.created, title: title,
                                     detail: entry.notes, entry: entry, state: state,
                                     tint: state?.ink ?? DiseaseColors.violet)
                return [row] + attachments
            }
            var result = limit.map { Array(recorded.prefix($0)) } ?? Array(recorded)
            var day = history.cardDay
            var remaining = limit ?? .max
            while day >= history.start && remaining > 0 {
                if !history.records(day).contains(where: { $0.kind == .status }),
                   let state = history.marker(on: day) {
                    result.append(HistoryRow(id: "day-\(day.timeIntervalSinceReferenceDate)", date: day,
                                             title: state.label,
                                             detail: day == history.start ? "Inicio del seguimiento" : "Continuación del seguimiento",
                                             tint: state.ink))
                    remaining -= 1
                }
                if history.marker(on: day) == nil, let status = history.status(on: day), status.state == .recovered {
                    day = history.day(status.date)
                } else {
                    day = history.shift(day, by: -1)
                }
            }
            let sorted = result.sorted { $0.date > $1.date }
            return Array(sorted.prefix(limit ?? sorted.count))
        case .symptoms, .medications:
            let kind: HealthKind = self == .symptoms ? .symptom : .medication
            let matches = history.entries.lazy.flatMap { healthRows(for: $0, kind: kind) }
            return limit.map { Array(matches.prefix($0)) } ?? Array(matches)
        }
    }

    private func healthRows(for entry: Entry, kind: HealthKind? = nil) -> [HistoryRow] {
        entry.health.filter { kind == nil || $0.kind == kind }.map { item in
            HistoryRow(id: "\(entry.id.uuidString)-\(item.id)", date: entry.created, title: item.name,
                       detail: item.detail, entry: entry,
                       tint: item.kind == .symptom ? DiseaseColors.violet : DiseaseColors.teal)
        }
    }
}

private struct HistoryRow: Identifiable {
    let id: String
    let date: Date
    let title: String
    let detail: String
    var entry: Entry?
    var state: DiseaseState?
    let tint: Color
}

private struct HistoryLine: View {
    let row: HistoryRow

    var body: some View {
        HStack(alignment: .top, spacing: 13) {
            Color.clear.frame(width: 9).accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 4) {
                if row.entry != nil {
                    Text(row.date, format: .dateTime.day().month(.abbreviated).year().hour().minute())
                        .font(.caption).foregroundStyle(.secondary)
                } else {
                    Text(row.date, format: .dateTime.day().month(.abbreviated).year())
                        .font(.caption).foregroundStyle(.secondary)
                }
                Text(row.title).font(.subheadline.weight(.semibold)).foregroundStyle(.primary)
                if let state = row.state, row.title != state.label {
                    Text(state.label).font(.caption.weight(.medium)).foregroundStyle(state.ink)
                }
                if !row.detail.isEmpty { Text(row.detail).font(.subheadline).foregroundStyle(.secondary) }
                if let entry = row.entry, !entry.photos.isEmpty {
                    Label(String(entry.photos.count), systemImage: "photo.on.rectangle")
                        .font(.caption).foregroundStyle(.secondary)
                }
            }
            .padding(.vertical, 13)
            .frame(maxWidth: .infinity, alignment: .leading)
            if row.entry != nil {
                Image(systemName: "chevron.right")
                    .font(.caption2.weight(.semibold))
                    .foregroundStyle(.tertiary)
                    .padding(.top, 23)
                    .accessibilityHidden(true)
            }
        }
        .overlay(alignment: .leading) {
            Rectangle().fill(Color.secondary.opacity(0.18)).frame(width: 1).padding(.leading, 4)
                .overlay(alignment: .topLeading) {
                    Circle().fill(row.tint).frame(width: 9, height: 9).padding(.top, 19)
                }
                .accessibilityHidden(true)
        }
        .padding(.horizontal, 16)
        .fixedSize(horizontal: false, vertical: true)
        .contentShape(Rectangle())
        .accessibilityElement(children: .combine)
    }
}

private struct IllustrationPicker: View {
    let illnessID: UUID
    @Environment(Journal.self) private var journal
    @Environment(\.dismiss) private var dismiss
    @State private var error: String?
    @State private var editing = false

    var body: some View {
        NavigationStack {
            ScrollView {
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 124), spacing: 12)], spacing: 12) {
                    ForEach(0..<12, id: \.self) { index in
                        let selected = journal.illness(illnessID).map {
                            !$0.showsAnimatedArtwork && $0.illustration == index
                        } == true
                        Button { save(index) } label: {
                            Image("disease-\(index)")
                                .resizable()
                                .aspectRatio(2, contentMode: .fit)
                                .clipShape(.rect(cornerRadius: 10))
                                .overlay(alignment: .topTrailing) {
                                    if selected {
                                        Image(systemName: "checkmark.circle.fill")
                                            .symbolRenderingMode(.palette)
                                            .foregroundStyle(.white, .blue)
                                            .padding(5)
                                    }
                                }
                        }
                        .buttonStyle(.plain)
                        .accessibilityLabel("Ilustración \(index + 1)")
                        .accessibilityAddTraits(selected ? .isSelected : [])
                    }
                }
                .padding(16)
                Button("Animación o GIF", systemImage: "photo.on.rectangle.angled") { editing = true }
                    .padding(.bottom, 15)
            }
            .background(DiseaseColors.grouped)
            .navigationTitle("Ilustración")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Listo", systemImage: "checkmark") { dismiss() }
                }
            }
            .sheet(isPresented: $editing) {
                if let illness = journal.illness(illnessID) {
                    IllnessForm(illness: illness, creating: false, showArtworkOptions: true) { _ in }
                }
            }
            .saveError($error)
        }
    }

    private func save(_ index: Int) {
        guard var illness = journal.illness(illnessID) else { return }
        illness.artwork = index
        illness.animatedArtwork = false
        do {
            try journal.save(illness)
        } catch {
            self.error = error.localizedDescription
        }
    }
}
