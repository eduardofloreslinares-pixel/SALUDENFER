import SwiftUI
import UIKit
import UniformTypeIdentifiers

struct HomeView: View {
    @Environment(Journal.self) private var journal
    @State private var path: [UUID] = []
    @State private var creating = false
    @State private var importing = false
    @State private var importMessage: String?

    var body: some View {
        NavigationStack(path: $path) {
            TimelineView(.everyMinute) { clock in
                ScrollView {
                    VStack(alignment: .leading, spacing: 10) {
                        Text(journal.illnesses.isEmpty ? "Ningún dato disponible" : "Registradas")
                            .font(.headline)
                            .padding(.horizontal, 4)
                            .accessibilityAddTraits(.isHeader)
                        if journal.loadError != nil {
                            ContentUnavailableView("Historial no disponible", systemImage: "lock",
                                                   description: Text("No se pudieron abrir los registros guardados."))
                        }
                        ForEach(journal.illnesses) { illness in
                            NavigationLink(value: illness.id) {
                                DiseaseCard(illness: illness, history: DiseaseHistory(illness: illness, now: max(clock.date, .now)))
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    .padding(.horizontal, 16)
                    .padding(.vertical, 12)
                    .frame(maxWidth: 620)
                    .frame(maxWidth: .infinity)
                }
                .background(DiseaseColors.grouped)
                .navigationTitle("Enfermedades")
                .navigationBarTitleDisplayMode(.large)
                .toolbar {
                    ToolbarItemGroup(placement: .topBarTrailing) {
                        Button("Importar historial", systemImage: "square.and.arrow.down") { importing = true }
                            .labelStyle(.iconOnly)
                            .disabled(journal.loadError != nil)
                        Button("Añadir enfermedad", systemImage: "plus") { creating = true }
                            .labelStyle(.iconOnly)
                            .disabled(journal.loadError != nil)
                    }
                }
            }
            .navigationDestination(for: UUID.self) { id in
                if let illness = journal.illness(id) {
                    IllnessDetail(illness: illness).id(id)
                } else {
                    ContentUnavailableView("Enfermedad no disponible", systemImage: "tray")
                }
            }
            .sheet(isPresented: $creating) {
                IllnessForm(illness: Illness(), creating: true) { id in path.append(id) }
            }
            .fileImporter(isPresented: $importing, allowedContentTypes: [.json]) { result in
                do {
                    let imported = try journal.importArchive(from: result.get())
                    importMessage = imported.illnesses == 0 && imported.entries == 0
                        ? "Este historial ya está en la app."
                        : "Enfermedades nuevas: \(imported.illnesses). Registros añadidos: \(imported.entries)."
                } catch {
                    importMessage = "No se pudo importar el historial. Comprueba que elegiste el archivo JSON de Enfermedades."
                }
            }
            .alert("Importar historial", isPresented: Binding(
                get: { importMessage != nil }, set: { if !$0 { importMessage = nil } }
            )) {
                Button("Aceptar", role: .cancel) { importMessage = nil }
            } message: {
                Text(importMessage ?? "")
            }
        }
    }
}

private struct DiseaseCard: View {
    let illness: Illness
    let history: DiseaseHistory

    var body: some View {
        let entry = history.cardEntry
        VStack(alignment: .leading, spacing: 0) {
            HStack(spacing: 8) {
                Label(entry?.status ?? "Sin registro",
                      systemImage: history.recovered ? "checkmark.circle.fill" : "waveform.path.ecg")
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(entry.map { Palette.severity($0.severity) } ?? Color.secondary)
                Spacer(minLength: 4)
                if history.recovered {
                    Text("Últ. vez: \(history.cardDay.formatted(.dateTime.day().month(.abbreviated)))")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                } else if entry != nil {
                    Text("Hoy").font(.caption).foregroundStyle(.secondary)
                }
                Image(systemName: "chevron.right")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.tertiary)
                    .accessibilityHidden(true)
            }

            Spacer(minLength: 24)
            HStack(alignment: .bottom, spacing: 12) {
                Text(illness.name)
                    .font(.title2.bold())
                    .foregroundStyle(.primary)
                Spacer(minLength: 0)
                if entry != nil {
                    DayColorGraph(values: history.colors(on: history.cardDay),
                                  trend: history.trend(on: history.cardDay), height: 34)
                        .frame(width: 69)
                }
            }
        }
        .padding(16)
        .frame(minHeight: 126)
        .background(DiseaseColors.surface, in: .rect(cornerRadius: 23))
        .accessibilityElement(children: .combine)
    }
}

private enum DetailSheet: Identifiable {
    case entry(Entry)
    case about, artwork, calendar

    var id: String {
        switch self {
        case .entry(let entry): entry.id.uuidString
        case .about: "about"
        case .artwork: "artwork"
        case .calendar: "calendar"
        }
    }
}

private struct IllnessDetail: View {
    let illness: Illness
    @State private var selectedDay = Calendar.current.startOfDay(for: .now)
    @State private var dayAnchor = Calendar.current.startOfDay(for: .now)
    @State private var sheet: DetailSheet?
    @State private var expanded = false
    @State private var followsToday = true
    @State private var calendarJump = 0

    var body: some View {
        TimelineView(.everyMinute) { clock in
            let history = DiseaseHistory(illness: illness, now: max(clock.date, .now))
            ScrollView {
                VStack(spacing: 0) {
                    DiseaseCalendar(history: history, selected: $selectedDay, anchorDay: dayAnchor)
                        .id(calendarJump)
                    VStack(alignment: .leading, spacing: 14) {
                        historySection(history)
                        HStack(alignment: .firstTextBaseline) {
                            Text("Acerca de la enfermedad").font(.title2.bold())
                                .accessibilityAddTraits(.isHeader)
                            Spacer()
                            Button("Editar") { sheet = .about }.font(.subheadline)
                        }
                        .padding(.top, 10)
                        about(history)
                    }
                    .padding(16)
                }
                .frame(maxWidth: 620)
                .frame(maxWidth: .infinity)
            }
            .background(DiseaseColors.grouped)
            .navigationTitle(illness.name)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItemGroup(placement: .topBarTrailing) {
                    Button("Calendario", systemImage: "calendar") { sheet = .calendar }
                        .labelStyle(.iconOnly)
                    Button("Estado de la enfermedad", systemImage: "plus") {
                        let date = history.entryTime(on: selectedDay)
                        let severity = history.lastSeverity(at: date) ?? 55
                        sheet = .entry(Entry(created: date, severity: severity))
                    }
                    .labelStyle(.iconOnly)
                    .disabled(selectedDay > history.today)
                }
            }
            .onChange(of: selectedDay) { followsToday = selectedDay == history.today }
            .onChange(of: history.today) {
                if followsToday {
                    selectedDay = history.today
                    dayAnchor = history.today
                    calendarJump += 1
                }
            }
            .sheet(item: $sheet) { item in
                switch item {
                case .entry(let entry):
                    EntryForm(illnessID: illness.id, entry: entry)
                case .about:
                    IllnessForm(illness: illness, creating: false) { _ in }
                case .artwork:
                    IllustrationPicker(illnessID: illness.id)
                case .calendar:
                    EpisodeCalendar(history: history, selected: selectedDay) { date in
                        selectedDay = date
                        dayAnchor = date
                        calendarJump += 1
                        sheet = nil
                    }
                }
            }
        }
    }

    private func historySection(_ history: DiseaseHistory) -> some View {
        let rows = HistoryRow.makeRows(history, limit: expanded ? nil : 7)
        return VStack(alignment: .leading, spacing: 10) {
            Text("Línea temporal").font(.title2.bold()).accessibilityAddTraits(.isHeader)
            if rows.isEmpty {
                Text("Todavía no hay registros de seguimiento.")
                    .font(.subheadline).foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(16)
                    .background(DiseaseColors.surface, in: .rect(cornerRadius: 14))
            } else {
                LazyVStack(spacing: 0) {
                    ForEach(expanded ? rows : Array(rows.prefix(6))) { row in
                        if let entry = row.entry {
                            Button { sheet = .entry(entry) } label: { HistoryLine(row: row) }
                                .buttonStyle(.plain)
                        } else {
                            HistoryLine(row: row)
                        }
                    }
                }
                .background(DiseaseColors.surface, in: .rect(cornerRadius: 14))
                if rows.count > 6 {
                    Button(expanded ? "Mostrar menos" : "Mostrar todos los datos") { expanded.toggle() }
                        .font(.subheadline.weight(.medium))
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 5)
                }
            }
        }
    }

    private func about(_ history: DiseaseHistory) -> some View {
        VStack(alignment: .leading, spacing: 0) {
            Button { sheet = .artwork } label: {
                IllnessIllustration(illness: illness)
                    .overlay(alignment: .bottomTrailing) {
                        Image(systemName: "photo.badge.plus")
                            .font(.subheadline.weight(.semibold))
                            .padding(10)
                            .glassEffect(.regular, in: .circle)
                            .padding(9)
                    }
            }
            .buttonStyle(.plain)
            .accessibilityLabel("Cambiar ilustración")

            VStack(alignment: .leading, spacing: 10) {
                Text(illness.name).font(.headline)
                if !illness.summary.isEmpty {
                    Text(illness.summary).font(.subheadline)
                        .foregroundStyle(.secondary)
                        .textSelection(.enabled)
                }
                Divider()
                LabeledContent("Veces que la tuviste", value: String(history.episodes.count))
                if let episode = history.latestEpisode {
                    LabeledContent("Última vez") {
                        VStack(alignment: .trailing, spacing: 2) {
                            Text(episode.start, format: .dateTime.day().month(.abbreviated).year())
                            if let end = episode.end {
                                Text("Hasta \(end.formatted(.dateTime.day().month(.abbreviated).year()))")
                                    .font(.caption)
                            } else {
                                Text("En curso").font(.caption)
                            }
                        }
                    }
                    ForEach(HealthKind.allCases) { kind in
                        let names = history.attachments(in: episode, kind: kind)
                        LabeledContent(kind.title, value: names.isEmpty ? "Sin registros" : names.joined(separator: ", "))
                    }
                }
            }
            .font(.subheadline)
            .padding(16)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(DiseaseColors.surface, in: .rect(cornerRadius: 16))
        .clipShape(.rect(cornerRadius: 16))
    }
}
struct PhotoStrip: View {
    let names: [String]
    let url: (String) -> URL
    var drafts: [String: Data] = [:]
    var remove: ((String) -> Void)?
    var open: ((String) -> Void)?

    var body: some View {
        ScrollView(.horizontal) {
            HStack(spacing: 8) {
                ForEach(names, id: \.self) { name in
                    let thumbnail = PhotoThumbnail(name: name, url: url(name), bytes: drafts[name])
                    Group {
                        if let open {
                            Button { open(name) } label: { thumbnail }
                                .buttonStyle(.plain)
                                .accessibilityLabel("Ver foto")
                        } else {
                            thumbnail
                        }
                    }
                    .overlay(alignment: .topTrailing) {
                        if let remove {
                            Button { remove(name) } label: {
                                Image(systemName: "xmark.circle.fill")
                                    .symbolRenderingMode(.palette)
                                    .foregroundStyle(.white, .black.opacity(0.78))
                                    .padding(7)
                            }
                            .buttonStyle(.plain)
                            .accessibilityLabel("Quitar foto")
                        }
                    }
                }
            }
        }
        .scrollIndicators(.hidden)
    }
}

private struct PhotoThumbnail: View {
    let name: String
    let url: URL
    let bytes: Data?
    @State private var image: UIImage?

    var body: some View {
        Group {
            if let image {
                Image(uiImage: image).resizable().scaledToFill()
            } else {
                Rectangle().fill(.primary.opacity(0.08))
                    .overlay(Image(systemName: "photo").foregroundStyle(.secondary))
            }
        }
        .frame(width: 92, height: 74)
        .clipShape(.rect(cornerRadius: 13))
        .accessibilityHidden(true)
        .task(id: name) {
            image = await Task.detached(priority: .utility) {
                PhotoDecoder.thumbnail(bytes: bytes, url: url, size: 220)
            }.value
        }
    }
}

private struct IllustrationPicker: View {
    let illnessID: UUID
    @Environment(Journal.self) private var journal
    @Environment(\.dismiss) private var dismiss
    @State private var error: String?
    @State private var editing = false

    var body: some View {
        NavigationStack {
            ScrollView {
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 124), spacing: 12)], spacing: 12) {
                    ForEach(0..<12, id: \.self) { index in
                        let selected = journal.illness(illnessID).map {
                            !$0.showsAnimatedArtwork && $0.illustration == index
                        } == true
                        Button { save(index) } label: {
                            Image("disease-\(index)")
                                .resizable()
                                .aspectRatio(2, contentMode: .fit)
                                .clipShape(.rect(cornerRadius: 10))
                                .overlay(alignment: .topTrailing) {
                                    if selected {
                                        Image(systemName: "checkmark.circle.fill")
                                            .symbolRenderingMode(.palette)
                                            .foregroundStyle(.white, .blue)
                                            .padding(5)
                                    }
                                }
                        }
                        .buttonStyle(.plain)
                        .accessibilityLabel("Ilustración \(index + 1)")
                        .accessibilityAddTraits(selected ? .isSelected : [])
                    }
                }
                .padding(16)
                Button("Animación o GIF", systemImage: "photo.on.rectangle.angled") { editing = true }
                    .padding(.bottom, 15)
            }
            .background(DiseaseColors.grouped)
            .navigationTitle("Ilustración")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Listo", systemImage: "checkmark") { dismiss() }
                }
            }
            .sheet(isPresented: $editing) {
                if let illness = journal.illness(illnessID) {
                    IllnessForm(illness: illness, creating: false, showArtworkOptions: true) { _ in }
                }
            }
            .saveError($error)
        }
    }

    private func save(_ index: Int) {
        guard var illness = journal.illness(illnessID) else { return }
        illness.artwork = index
        illness.animatedArtwork = false
        do {
            try journal.save(illness)
        } catch {
            self.error = error.localizedDescription
        }
    }
}

private struct DiseaseCalendar: View {
    let history: DiseaseHistory
    @Binding var selected: Date
    let anchorDay: Date

    @Environment(\.colorScheme) private var colorScheme
    @State private var restingDay: Date
    @State private var drag: HorizontalDrag = .undecided
    @GestureState private var gestureActive = false
    @ScaledMetric(relativeTo: .caption) private var stripHeight: CGFloat = 96

    private enum HorizontalDrag: Equatable {
        case undecided, vertical
        case horizontal(CGFloat)

        var translation: CGFloat {
            if case .horizontal(let value) = self { return value }
            return 0
        }
    }

    private static let cellWidth: CGFloat = 48
    private static let stride: CGFloat = 54
    private var first: Date { min(history.start, history.shift(anchorDay, by: -90), history.shift(history.today, by: -90)) }
    private var last: Date { max(history.shift(anchorDay, by: 45), history.shift(history.today, by: 45)) }
    private var translation: CGFloat {
        let minimum = -CGFloat(distance(to: last)) * Self.stride
        let maximum = -CGFloat(distance(to: first)) * Self.stride
        return min(maximum, max(minimum, drag.translation))
    }
    private var centeredDay: Date {
        history.shift(restingDay, by: Int((-translation / Self.stride).rounded()))
    }

    init(history: DiseaseHistory, selected: Binding<Date>, anchorDay: Date) {
        self.history = history
        _selected = selected
        self.anchorDay = anchorDay
        _restingDay = State(initialValue: selected.wrappedValue)
    }

    var body: some View {
        VStack(spacing: 5) {
            HStack(spacing: 6) {
                arrow("Día anterior", icon: "chevron.left", by: -1)
                Text(heading).font(.title3.weight(.semibold))
                    .multilineTextAlignment(.center)
                    .accessibilityAddTraits(.isHeader)
                arrow("Día siguiente", icon: "chevron.right", by: 1)
            }
            .padding(.horizontal, 8)

            Image(systemName: "triangle.fill")
                .font(.system(size: 8, weight: .semibold))
                .rotationEffect(.degrees(180))
                .accessibilityHidden(true)

            GeometryReader { geometry in
                let radius = Int(ceil(geometry.size.width / (2 * Self.stride))) + 1
                let days = (-radius...radius)
                    .map { history.shift(centeredDay, by: $0) }
                    .filter { $0 >= first && $0 <= last }
                ZStack {
                    ForEach(days, id: \.self) { day in
                        let x = CGFloat(distance(to: day)) * Self.stride + translation
                        dayCell(day)
                            .offset(x: x)
                            .accessibilityHidden(abs(x) > geometry.size.width / 2)
                    }
                }
                .frame(width: geometry.size.width, height: geometry.size.height)
                .clipped()
                .contentShape(Rectangle())
                .simultaneousGesture(dayDrag)
            }
            .frame(height: stripHeight)
        }
        .padding(.vertical, 10)
        .frame(maxWidth: .infinity)
        .background(colorScheme == .dark ? Color.black : Color(uiColor: .systemBackground))
        .onChange(of: centeredDay) { _, day in selected = day }
        .onChange(of: gestureActive) {
            if !gestureActive { drag = .undecided }
        }
        .sensoryFeedback(.selection, trigger: centeredDay)
    }

    private var dayDrag: some Gesture {
        DragGesture(minimumDistance: 10)
            .updating($gestureActive) { _, active, _ in active = true }
            .onChanged { value in
                switch drag {
                case .undecided:
                    drag = abs(value.translation.width) > abs(value.translation.height)
                        ? .horizontal(value.translation.width) : .vertical
                case .horizontal:
                    drag = .horizontal(value.translation.width)
                case .vertical:
                    break
                }
            }
            .onEnded { value in
                guard case .horizontal = drag else {
                    drag = .undecided
                    return
                }
                let days = Int((-value.translation.width / Self.stride).rounded())
                choose(history.shift(restingDay, by: days))
            }
    }

    private var heading: String {
        let day = centeredDay
        let format = Date.FormatStyle(locale: Locale(identifier: "es_PE")).day().month(.wide)
        if day == history.today { return "Hoy, \(day.formatted(format))" }
        if !history.calendar.isDate(day, equalTo: history.today, toGranularity: .year) {
            return day.formatted(format.year())
        }
        return day.formatted(format)
    }

    private func distance(to day: Date) -> Int {
        history.calendar.dateComponents([.day], from: restingDay, to: day).day ?? 0
    }

    private func choose(_ day: Date) {
        let bounded = min(last, max(first, day))
        restingDay = bounded
        drag = .undecided
        selected = bounded
    }

    private func arrow(_ label: String, icon: String, by offset: Int) -> some View {
        let target = history.shift(centeredDay, by: offset)
        return Button { choose(target) } label: {
            Image(systemName: icon)
                .font(.subheadline.weight(.semibold))
                .frame(width: 38, height: 44)
                .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .foregroundStyle(.secondary)
        .disabled(target < first || target > last)
        .accessibilityLabel(label)
    }

    private func dayCell(_ day: Date) -> some View {
        let current = day == centeredDay
        return Button { choose(day) } label: {
            VStack(spacing: 5) {
                Text(day, format: .dateTime.weekday(.narrow))
                    .font(.caption2.weight(.semibold))
                    .foregroundStyle(current ? Color(uiColor: .systemBackground) : .secondary)
                    .padding(4)
                    .background(current ? Color.primary : Color.clear, in: .circle)
                DayColorGraph(values: history.colors(on: day), trend: history.trend(on: day), height: 38)
                Text(day, format: .dateTime.day())
                    .font(.caption.weight(current ? .bold : .regular))
                    .foregroundStyle(current ? .primary : .secondary)
                    .fixedSize()
            }
            .frame(width: Self.cellWidth)
            .padding(.vertical, 3)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .accessibilityLabel(Text(day, format: .dateTime.weekday(.wide).day().month(.wide).year()))
        .accessibilityAddTraits(current ? .isSelected : [])
    }
}

private struct DayColorGraph: View {
    let values: [Int]
    let trend: EntryEvolution?
    let height: CGFloat

    var body: some View {
        ZStack {
            if let first = values.first {
                Capsule().fill(Palette.severity(first))
                if values.contains(where: { $0 != first }) {
                    Capsule().fill(LinearGradient(colors: values.map { Palette.severity($0) },
                                                  startPoint: .leading, endPoint: .trailing))
                }
                if let trend, trend != .stable {
                    Image(systemName: trend.graphIcon)
                        .font(.caption2.weight(.bold))
                        .foregroundStyle(.primary)
                        .frame(width: 23, height: 23)
                        .glassEffect(.regular, in: .circle)
                }
            } else {
                Color.clear
            }
        }
        .frame(height: height)
        .accessibilityHidden(true)
    }
}

private extension EntryEvolution {
    var graphIcon: String {
        switch self {
        case .recovering, .improving, .slightImprovement: "arrow.down"
        case .slightWorsening, .worsening: "arrow.up"
        case .relapse: "arrow.counterclockwise"
        case .stable: "minus"
        }
    }
}

private struct EpisodeCalendar: View {
    let history: DiseaseHistory
    let selected: Date
    let select: (Date) -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var month: Date

    init(history: DiseaseHistory, selected: Date, select: @escaping (Date) -> Void) {
        self.history = history
        self.selected = selected
        self.select = select
        _month = State(initialValue: history.calendar.dateInterval(of: .month, for: selected)?.start ?? selected)
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 13) {
                    HStack {
                        monthArrow("Mes anterior", icon: "chevron.left", offset: -1)
                        Spacer(minLength: 6)
                        Text(month, format: .dateTime.month(.wide).year())
                            .font(.title3.bold()).accessibilityAddTraits(.isHeader)
                        Spacer(minLength: 6)
                        monthArrow("Mes siguiente", icon: "chevron.right", offset: 1)
                    }
                    let inMonth = history.calendar.range(of: .day, in: .month, for: month)?.count ?? 30
                    let firstWeekday = (history.calendar.component(.weekday, from: month) + 5) % 7
                    LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 3), count: 7), spacing: 8) {
                        ForEach(Array(["L", "M", "M", "J", "V", "S", "D"].enumerated()), id: \.offset) { _, day in
                            Text(day).font(.caption.weight(.medium)).foregroundStyle(.secondary)
                        }
                        ForEach(0..<firstWeekday, id: \.self) { _ in Color.clear.frame(height: 1) }
                        ForEach(0..<inMonth, id: \.self) { index in
                            monthCell(history.shift(month, by: index))
                        }
                    }
                }
                .padding(14)
                .background(DiseaseColors.surface, in: .rect(cornerRadius: 20))
                .padding(16)
            }
            .background(DiseaseColors.grouped)
            .navigationTitle("Calendario")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cerrar") { dismiss() } }
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Hoy") {
                        month = history.calendar.dateInterval(of: .month, for: history.today)?.start ?? history.today
                    }
                }
            }
        }
    }

    private func monthArrow(_ label: String, icon: String, offset: Int) -> some View {
        Button {
            if let target = history.calendar.date(byAdding: .month, value: offset, to: month) {
                month = target
            }
        } label: {
            Image(systemName: icon).font(.subheadline.weight(.semibold))
                .frame(width: 40, height: 40)
                .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .accessibilityLabel(label)
    }

    private func monthCell(_ day: Date) -> some View {
        Button { select(day) } label: {
            VStack(spacing: 3) {
                Text(day, format: .dateTime.day())
                    .font(.caption.weight(day == selected ? .bold : .regular))
                    .foregroundStyle(day == history.today ? Color.accentColor : .primary)
                DayColorGraph(values: history.colors(on: day), trend: history.trend(on: day), height: 26)
            }
            .padding(3)
            .frame(maxWidth: .infinity, minHeight: 47)
            .background(day == selected ? Color.accentColor.opacity(0.10) : Color.clear, in: .rect(cornerRadius: 8))
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .accessibilityLabel(Text(day, format: .dateTime.weekday(.wide).day().month(.wide).year()))
        .accessibilityAddTraits(day == selected ? .isSelected : [])
    }
}

private struct HistoryRow: Identifiable {
    let id: String
    let date: Date
    let title: String
    let detail: String
    let severity: Int?
    var entry: Entry?

    static func makeRows(_ history: DiseaseHistory, limit: Int?) -> [Self] {
        var rows = history.entries.prefix(limit ?? history.entries.count).map { entry in
            HistoryRow(id: entry.id.uuidString, date: entry.created, title: entry.displayTitle,
                       detail: entry.notes, severity: entry.kind == .status ? entry.severity : nil, entry: entry)
        }
        var remaining = limit ?? Int.max
        for episode in history.episodes.reversed() where remaining > 0 {
            let first = history.day(episode.start)
            var day = episode.end.map { history.day($0) } ?? history.today
            while day > first && remaining > 0 {
                if let continuation = history.continuation(on: day),
                   episode.end.map({ day < $0 }) ?? true {
                    let title = continuation.days == 1 ? "Llevas 1 día enfermo" : "Llevas \(continuation.days) días enfermo"
                    rows.append(HistoryRow(id: "day-\(day.timeIntervalSinceReferenceDate)", date: day,
                                           title: title, detail: "Continuación del seguimiento",
                                           severity: continuation.severity))
                    remaining -= 1
                }
                day = history.shift(day, by: -1)
            }
        }
        let sorted = rows.sorted { $0.date > $1.date }
        return Array(sorted.prefix(limit ?? sorted.count))
    }
}

private struct HistoryLine: View {
    let row: HistoryRow

    var body: some View {
        HStack(alignment: .top, spacing: 13) {
            Color.clear.frame(width: 9).accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 5) {
                if row.entry != nil {
                    Text(row.date, format: .dateTime.day().month(.abbreviated).year().hour().minute())
                } else {
                    Text(row.date, format: .dateTime.day().month(.abbreviated).year())
                }
                Text(row.title).font(.subheadline.weight(.semibold)).foregroundStyle(.primary)
                if !row.detail.isEmpty { Text(row.detail).font(.subheadline) }
                if let entry = row.entry {
                    ForEach(entry.health) { item in
                        Label(item.name, systemImage: item.kind.icon)
                            .foregroundStyle(item.kind == .symptom ? DiseaseColors.violet : DiseaseColors.teal)
                    }
                    if !entry.photos.isEmpty { Label(String(entry.photos.count), systemImage: "photo.on.rectangle") }
                }
            }
            .font(.caption)
            .foregroundStyle(.secondary)
            .padding(.vertical, 13)
            .frame(maxWidth: .infinity, alignment: .leading)

            if row.entry != nil {
                Image(systemName: "chevron.right")
                    .font(.caption2.weight(.semibold))
                    .foregroundStyle(.tertiary)
                    .padding(.top, 23)
                    .accessibilityHidden(true)
            }
        }
        .overlay(alignment: .leading) {
            Rectangle().fill(Color.secondary.opacity(0.18)).frame(width: 1).padding(.leading, 4)
                .overlay(alignment: .topLeading) {
                    Circle().fill(row.severity.map { Palette.severity($0) } ?? DiseaseColors.violet)
                        .frame(width: 9, height: 9)
                        .padding(.top, 19)
                }
                .accessibilityHidden(true)
        }
        .padding(.horizontal, 16)
        .fixedSize(horizontal: false, vertical: true)
        .contentShape(Rectangle())
        .accessibilityElement(children: .combine)
    }
}
