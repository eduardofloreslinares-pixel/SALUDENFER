import HealthKit
import SwiftUI

struct Symptom: Identifiable {
    let id: HKCategoryTypeIdentifier
    let name: String
    var type: HKCategoryType? { HKObjectType.categoryType(forIdentifier: id) }

    init(_ id: HKCategoryTypeIdentifier, _ name: String) {
        self.id = id
        self.name = name
    }

    static let all = [
        Symptom(.acne, "Acné"), Symptom(.chestTightnessOrPain, "Dolor u opresión en el pecho"),
        Symptom(.hotFlashes, "Bochornos"), Symptom(.hairLoss, "Caída del cabello"),
        Symptom(.appetiteChanges, "Cambios de apetito"), Symptom(.moodChanges, "Cambios de ánimo"),
        Symptom(.sleepChanges, "Cambios en el sueño"), Symptom(.abdominalCramps, "Cólicos abdominales"),
        Symptom(.sinusCongestion, "Congestión nasal"), Symptom(.fainting, "Desmayo"),
        Symptom(.diarrhea, "Diarrea"), Symptom(.shortnessOfBreath, "Dificultad para respirar"),
        Symptom(.headache, "Dolor de cabeza"), Symptom(.soreThroat, "Dolor de garganta"),
        Symptom(.breastPain, "Dolor en los senos"), Symptom(.generalizedBodyAche, "Dolor generalizado"),
        Symptom(.lowerBackPain, "Dolor lumbar"), Symptom(.pelvicPain, "Dolor pélvico"),
        Symptom(.chills, "Escalofríos"), Symptom(.constipation, "Estreñimiento"),
        Symptom(.fatigue, "Fatiga"), Symptom(.fever, "Fiebre"),
        Symptom(.bloating, "Hinchazón abdominal"), Symptom(.bladderIncontinence, "Incontinencia urinaria"),
        Symptom(.skippedHeartbeat, "Latidos omitidos"), Symptom(.memoryLapse, "Lapsos de memoria"),
        Symptom(.dizziness, "Mareos"), Symptom(.nausea, "Náuseas"),
        Symptom(.rapidPoundingOrFlutteringHeartbeat, "Palpitaciones"), Symptom(.lossOfTaste, "Pérdida del gusto"),
        Symptom(.lossOfSmell, "Pérdida del olfato"), Symptom(.drySkin, "Piel seca"),
        Symptom(.heartburn, "Acidez"), Symptom(.vaginalDryness, "Sequedad vaginal"),
        Symptom(.runnyNose, "Secreción nasal"), Symptom(.wheezing, "Sibilancias"),
        Symptom(.nightSweats, "Sudores nocturnos"), Symptom(.coughing, "Tos"), Symptom(.vomiting, "Vómitos")
    ].sorted { $0.name.localizedStandardCompare($1.name) == .orderedAscending }
}

enum SymptomIntensity: String, CaseIterable, Identifiable {
    case unspecified = "Sin especificar"
    case notPresent = "Ausente"
    case mild = "Leve"
    case moderate = "Moderado"
    case severe = "Intenso"

    var id: String { rawValue }
    var category: HKCategoryValueSeverity {
        switch self {
        case .unspecified: .unspecified
        case .notPresent: .notPresent
        case .mild: .mild
        case .moderate: .moderate
        case .severe: .severe
        }
    }

    static func name(for value: Int) -> String {
        allCases.first { $0.category.rawValue == value }?.rawValue ?? unspecified.rawValue
    }
}

@MainActor
final class HealthBridge {
    static let shared = HealthBridge()
    private let store = HKHealthStore()
    private init() {}

    private enum AccessError: LocalizedError {
        case unavailable, noWriteAccess
        var errorDescription: String? {
            switch self {
            case .unavailable: "Apple Salud no está disponible en este dispositivo."
            case .noWriteAccess: "Activa el permiso para guardar este síntoma en Apple Salud."
            }
        }
    }

    func request(_ kind: HealthKind) async throws {
        guard HKHealthStore.isHealthDataAvailable() else { throw AccessError.unavailable }
        switch kind {
        case .medication:
            try await store.requestPerObjectReadAuthorization(for: HKObjectType.userAnnotatedMedicationType(), predicate: nil)
        case .symptom:
            let types = Set<HKObjectType>(Symptom.all.compactMap { $0.type })
            try await store.requestAuthorization(toShare: [], read: types)
        }
    }

    func attachments(_ kind: HealthKind) async throws -> [HealthAttachment] {
        guard HKHealthStore.isHealthDataAvailable() else { throw AccessError.unavailable }
        switch kind {
        case .medication:
            let descriptor = HKUserAnnotatedMedicationQueryDescriptor(predicate: nil, limit: nil)
            let medications = try await descriptor.result(for: store)
            return medications
                .sorted { $0.medication.displayText.localizedStandardCompare($1.medication.displayText) == .orderedAscending }
                .map { item in
                    let name = item.medication.displayText
                    let nickname = item.nickname ?? ""
                    let id = (try? NSKeyedArchiver.archivedData(withRootObject: item.medication.identifier,
                                                              requiringSecureCoding: true))?.base64EncodedString()
                        ?? name + "|" + nickname
                    return HealthAttachment(id: "salud-medicamento-" + id, kind: .medication, name: name,
                                            detail: [nickname, item.isArchived ? "Archivado" : ""]
                                                .filter { !$0.isEmpty }.joined(separator: " · "),
                                            fromHealth: true)
                }
        case .symptom:
            let names = Dictionary(uniqueKeysWithValues: Symptom.all.map { ($0.id.rawValue, $0.name) })
            let query = HKSampleQueryDescriptor<HKCategorySample>(
                predicates: Symptom.all.compactMap { symptom in
                    symptom.type.map { .categorySample(type: $0) }
                },
                sortDescriptors: [SortDescriptor(\HKCategorySample.startDate, order: .reverse)]
            )
            return try await query.result(for: store).compactMap { sample in
                guard let name = names[sample.categoryType.identifier] else { return nil }
                return HealthAttachment(id: sample.uuid.uuidString, kind: .symptom, name: name,
                                        detail: SymptomIntensity.name(for: sample.value),
                                        date: sample.startDate, fromHealth: true)
            }
        }
    }

    func save(_ symptom: Symptom, intensity: SymptomIntensity, date: Date) async throws -> HealthAttachment {
        guard HKHealthStore.isHealthDataAvailable(), let type = symptom.type else { throw AccessError.unavailable }
        try await store.requestAuthorization(toShare: [type], read: [])
        guard store.authorizationStatus(for: type) == .sharingAuthorized else { throw AccessError.noWriteAccess }
        let sample = HKCategorySample(type: type, value: intensity.category.rawValue, start: date, end: date)
        try await store.save(sample)
        return HealthAttachment(id: sample.uuid.uuidString, kind: .symptom, name: symptom.name,
                                detail: intensity.rawValue, date: date, fromHealth: true)
    }
}

struct HealthPicker: View {
    let kind: HealthKind
    @Binding var selected: [HealthAttachment]
    @Environment(\.dismiss) private var dismiss
    @State private var imported: [HealthAttachment] = []
    @State private var busy = false
    @State private var message: String?
    @State private var search = ""
    @State private var adding = false

    var body: some View {
        NavigationStack {
            List {
                Section {
                    Button {
                        Task { await load(request: true) }
                    } label: {
                        Label("Conectar con Apple Salud", systemImage: "heart.text.clipboard")
                    }
                    Button { adding = true } label: {
                        Label("Añadir manualmente", systemImage: "plus")
                    }
                }
                Section("De Apple Salud") {
                    if busy {
                        ProgressView()
                    } else if let message {
                        Text(message).foregroundStyle(.secondary)
                    } else if imported.isEmpty {
                        Text("Aquí verás los datos que compartas desde Salud.").foregroundStyle(.secondary)
                    } else {
                        ForEach(imported.filter { search.isEmpty || $0.name.localizedCaseInsensitiveContains(search) || $0.detail.localizedCaseInsensitiveContains(search) }) { item in
                            Button {
                                if selected.contains(where: { $0.id == item.id }) {
                                    selected.removeAll { $0.id == item.id }
                                } else {
                                    selected.append(item)
                                }
                            } label: {
                                HStack {
                                    HealthAttachmentLabel(item: item)
                                    Spacer()
                                    Image(systemName: selected.contains(where: { $0.id == item.id })
                                          ? "checkmark.circle.fill" : "circle")
                                        .foregroundStyle(.primary)
                                }
                            }
                            .buttonStyle(.plain)
                        }
                    }
                }
            }
            .navigationTitle(kind.title)
            .navigationBarTitleDisplayMode(.inline)
            .searchable(text: $search, prompt: "Buscar en los datos de Salud")
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Listo", systemImage: "checkmark") { dismiss() }
                }
            }
            .sheet(isPresented: $adding) {
                ManualHealthForm(kind: kind) { item in
                    if !selected.contains(where: { $0.id == item.id }) { selected.append(item) }
                }
            }
            .task { await load(request: false) }
        }
    }

    private func load(request: Bool) async {
        guard !busy else { return }
        busy = true
        defer { busy = false }
        do {
            if request { try await HealthBridge.shared.request(kind) }
            imported = try await HealthBridge.shared.attachments(kind)
            message = nil
        } catch {
            message = request ? error.localizedDescription : nil
        }
    }
}

struct HealthAttachmentLabel: View {
    let item: HealthAttachment

    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: item.kind.icon)
                .font(.subheadline)
                .frame(width: 24)
                .foregroundStyle(.primary)
                .accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 2) {
                Text(item.name).font(.subheadline.weight(.medium)).foregroundStyle(.primary)
                if !item.detail.isEmpty {
                    Text(item.detail).font(.caption).foregroundStyle(.secondary)
                }
                if let date = item.date {
                    Text(date, format: .dateTime.day().month(.abbreviated).year().hour().minute())
                        .font(.caption).foregroundStyle(.secondary)
                }
            }
        }
    }
}

private struct ManualHealthForm: View {
    let kind: HealthKind
    let onAdd: (HealthAttachment) -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var symptom: HKCategoryTypeIdentifier?
    @State private var name = ""
    @State private var detail = ""
    @State private var intensity = SymptomIntensity.unspecified
    @State private var date = Date()
    @State private var write = false
    @State private var saving = false
    @State private var error: String?
    private var mapped: Symptom? { Symptom.all.first { $0.id == symptom } }

    var body: some View {
        NavigationStack {
            Form {
                if kind == .symptom {
                    Picker("Tipo", selection: $symptom) {
                        Text("Personalizado").tag(Optional<HKCategoryTypeIdentifier>.none)
                        ForEach(Symptom.all) { item in Text(item.name).tag(Optional(item.id)) }
                    }
                    if mapped == nil { TextField("Nombre del síntoma", text: $name) }
                    Picker("Intensidad", selection: $intensity) {
                        ForEach(SymptomIntensity.allCases) { item in Text(item.rawValue).tag(item) }
                    }
                    DatePicker("Fecha y hora", selection: $date, in: ...Date())
                    if mapped != nil {
                        Section {
                            Toggle("Guardar también en Salud", isOn: $write)
                        } footer: {
                            Text("Al adjuntar, se guardará el síntoma en Salud de inmediato.")
                        }
                    }
                } else {
                    TextField("Nombre del medicamento", text: $name)
                    TextField("Dosis o nota (opcional)", text: $detail)
                }
                if let error { Text(error).foregroundStyle(.red) }
            }
            .navigationTitle(kind.singular)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancelar") { dismiss() }.disabled(saving) }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Adjuntar") { Task { await attach() } }
                        .disabled(saving || (mapped == nil && name.trimmed.isEmpty))
                }
            }
            .interactiveDismissDisabled(saving)
        }
    }

    private func attach() async {
        guard !saving else { return }
        saving = true
        defer { saving = false }
        do {
            let item: HealthAttachment
            if kind == .symptom, let mapped, write {
                item = try await HealthBridge.shared.save(mapped, intensity: intensity, date: date)
            } else {
                item = HealthAttachment(kind: kind, name: mapped?.name ?? name.trimmed,
                                        detail: kind == .symptom ? intensity.rawValue : detail.trimmed,
                                        date: kind == .symptom ? date : nil)
            }
            onAdd(item)
            dismiss()
        } catch {
            self.error = error.localizedDescription
        }
    }
}
