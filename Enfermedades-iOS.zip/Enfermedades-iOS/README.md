# Enfermedades

Diario nativo de iPhone en SwiftUI. Usa el diseño de la pestaña Enfermedades de Salud para Android y conserva el diario y la integración con Apple Salud. Requiere iOS 26 o posterior.

## Actualizar la app existente

Reemplaza `Enfermedades-iOS.zip` en el mismo repositorio y conserva el workflow existente en `.github/workflows/build-ios.yml`. Si el repositorio contiene el código descomprimido, reemplaza esos archivos en su ubicación actual. **Compilar Enfermedades** genera el mismo artefacto `Enfermedades.ipa`.

El proyecto y esquema siguen llamándose `Enfermedades` y conservan el identificador `com.eflores.enfermedades`. Firma la IPA con la misma cuenta y el mismo identificador efectivo que usaste en la instalación anterior y actualiza sobre la app instalada. El diario conserva su formato JSON y ubicación. En una compilación local, abre `Enfermedades.xcodeproj` con Xcode 26 o posterior y usa el perfil de aprovisionamiento de la instalación anterior.

Para usar Apple Salud, el perfil y la firma final deben incluir `com.apple.developer.healthkit`. El diario también admite síntomas y medicamentos ingresados manualmente.

## Registrar una evolución

1. Toca **+** en la pantalla principal para crear una enfermedad.
2. En el detalle, desliza las fechas o toca el calendario para elegir un día. Toca **+** para abrir **Estado de la enfermedad**. El deslizador empieza en la intensidad anterior. El mismo formulario admite notas, fotos, síntomas y medicamentos.
3. Las entradas del día forman su gráfico de color. A partir de medianoche, la línea temporal muestra «Llevas … días enfermo» con la intensidad anterior. Si la app estaba cerrada, el historial calcula esos días al abrirla.
4. Llevar el deslizador al extremo verde cierra el episodio. Los días siguientes quedan vacíos hasta que vuelvas a registrar una intensidad mayor a cero.
5. En **Acerca de la enfermedad** puedes ver los episodios y los síntomas y medicamentos del más reciente. Toca la ilustración para cambiarla o configurar un GIF.

Las enfermedades, los registros y sus adjuntos se guardan en el dispositivo con protección de archivos. El diario está excluido de las copias de seguridad del sistema. Los síntomas que compartas con Apple Salud se administran ahí de forma independiente.

## Importar historial

En la pantalla principal, toca **Importar historial** (el icono a la izquierda del signo +) y selecciona el JSON de Enfermedades desde Archivos. Los registros se incorporan al diario local. Si vuelves a importar el mismo archivo, conserva los registros existentes sin duplicarlos.
