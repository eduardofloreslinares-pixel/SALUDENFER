# Enfermedades

Diario nativo de iPhone en SwiftUI. Usa el diseño de la pestaña Enfermedades de Salud para Android y conserva el diario y la integración con Apple Salud. Requiere iOS 26 o posterior.

## Actualizar la app existente

Reemplaza `Enfermedades-iOS.zip` en el mismo repositorio y conserva el workflow existente en `.github/workflows/build-ios.yml`. Si el repositorio contiene el código descomprimido, reemplaza esos archivos en su ubicación actual. **Compilar Enfermedades** genera el mismo artefacto `Enfermedades.ipa`.

El proyecto y esquema siguen llamándose `Enfermedades` y conservan el identificador `com.eflores.enfermedades`. Firma la IPA con la misma cuenta y el mismo identificador efectivo que usaste en la instalación anterior y actualiza sobre la app instalada. El diario conserva su formato JSON y ubicación. En una compilación local, abre `Enfermedades.xcodeproj` con Xcode 26 o posterior y usa el perfil de aprovisionamiento de la instalación anterior.

Para usar Apple Salud, el perfil y la firma final deben incluir `com.apple.developer.healthkit`. El diario también admite síntomas y medicamentos ingresados manualmente.

## Registrar una evolución

1. Toca **+** para crear una enfermedad. Escribe el nombre y, si quieres, una descripción.
2. Abre la tarjeta y elige un día del calendario. En **Registro del día**, toca **Enfermedad**, **Síntomas**, **Notas** o **Medicamentos**. El botón **Agregar** permite crear un registro adicional en la fecha seleccionada.
3. Escoge uno de los cinco estados y ajusta la intensidad si lo deseas. Los días siguientes muestran la continuación del último estado en curso. **Recuperada** cierra ese período y un estado en curso posterior lo reabre.
4. Los registros admiten fotos y adjuntos. En **Síntomas** o **Medicamentos**, puedes conectar Apple Salud o registrar el dato manualmente.
5. En **Acerca de la enfermedad**, toca la ilustración para elegir entre los doce diseños originales o configurar una animación o GIF de hasta 20 MB.

Las enfermedades, los registros y sus adjuntos se guardan en el dispositivo con protección de archivos. El diario está excluido de las copias de seguridad del sistema. Los síntomas que compartas con Apple Salud se administran ahí de forma independiente.
