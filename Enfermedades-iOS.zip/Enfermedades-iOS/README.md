# Enfermedades

Diario nativo de iPhone para registrar cómo evoluciona una enfermedad. Requiere iOS 26 o posterior.

## Compilar y firmar

Abre `Enfermedades.xcodeproj` con Xcode 26 o posterior. En **Signing & Capabilities**, selecciona tu equipo de Apple, usa un identificador de paquete disponible y verifica que la capacidad **HealthKit** esté habilitada para ese identificador. Para verificar los permisos de Apple Salud, ejecuta la app en un iPhone con un perfil de aprovisionamiento que incluya `com.apple.developer.healthkit`.

Coloca `.github/workflows/build-ios.yml` en la raíz del repositorio de GitHub. Puedes subir el proyecto de Xcode en la raíz, dentro de `Enfermedades-iOS`, o subir directamente `Enfermedades-iOS.zip` junto al workflow. El flujo **Compilar Enfermedades** genera `Enfermedades.ipa` con una firma local que incluye el permiso de HealthKit. Importa la IPA a SideStore para que la vuelva a firmar con tu cuenta. La firma final y el perfil de aprovisionamiento deben incluir `com.apple.developer.healthkit` para conectar con Salud. Si falta el permiso, el diario admite adjuntos manuales.

## Registrar una evolución

1. Crea la enfermedad con el botón **+**. Puedes elegir una de las tres animaciones o importar un GIF de hasta 20 MB desde Archivos.
2. En el detalle, toca el **+** inferior. Escribe el título y el contenido, ajusta el color y adjunta fotos, síntomas o medicamentos.
3. El extremo verde del deslizador corresponde a **Curada**. La tarjeta pierde su tinte y muestra la fecha del último registro activo. Si vuelves a registrar un valor distinto de cero, se reactiva la misma enfermedad.
4. En **Síntomas** o **Medicamentos**, toca **Conectar con Apple Salud** y elige qué compartir. Puedes importar tus medicamentos y síntomas autorizados, registrar un síntoma compatible en Salud al adjuntarlo, o escribir un medicamento o síntoma localmente.

Las enfermedades, sus registros y sus adjuntos se guardan en el dispositivo con protección de archivos. Los datos del diario se excluyen de las copias de seguridad del sistema. Los síntomas que decidas guardar en Apple Salud se administran ahí de forma independiente.
